/* =========================================================================
   CISSP 演習帳 — application
   ES2017 target. No optional chaining / nullish coalescing (older iOS Safari).
   ========================================================================= */
(function () {
"use strict";

/* ---------------------------------------------------------------- data */
var DATA = window.__CISSP__;
var DOMAINS = DATA.domains;
var QS = DATA.questions;
var CARDS = DATA.cards;
var WRITTEN = DATA.written;
var CHEATS = DATA.cheats;

var DCOLOR = {d1:"#6E8FF0",d2:"#4FB0D6",d3:"#3FBFA0",d4:"#7CC24C",
              d5:"#E0B23C",d6:"#EE8C43",d7:"#E85D6B",d8:"#B47AE4"};
/* Short labels for tight spots (legend, bar charts). Full names are used wherever there is room. */
var DSHORT = {d1:"リスク管理",d2:"資産の保護",d3:"設計・暗号",d4:"ネットワーク",
              d5:"IAM",d6:"評価・テスト",d7:"運用",d8:"開発"};

/* Inline SVG icons — consistent weight at 23px, no font dependency. */
function ic(d, extra) {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
         'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + (extra || "") + "</svg>";
}
var ICON = {
  today: ic('<path d="M12 3.2 19.4 7v10L12 20.8 4.6 17V7Z"/><circle cx="12" cy="12" r="3.2"/>'),
  drill: ic('<path d="M4 6.5h9M4 12h9M4 17.5h6"/><path d="M20.5 4.6 15 10.1l-.9 2.8 2.8-.9 5.5-5.5a1.4 1.4 0 0 0-1.9-1.9Z"/>'),
  cards: ic('<rect x="3" y="7.5" width="14" height="12.5" rx="2.2"/><path d="M7 4.5h11a2.2 2.2 0 0 1 2.2 2.2v10"/>'),
  read:  ic('<path d="M12 6.6C10.4 5.3 8.3 4.7 5 4.7v13c3.3 0 5.4.6 7 1.9 1.6-1.3 3.7-1.9 7-1.9v-13c-3.3 0-5.4.6-7 1.9Z"/><path d="M12 6.6v13.1"/>'),
  stats: ic('<path d="M4.5 20V13m5 7V5.4m5 14.6v-9.3M19.5 20V8.2"/>'),
  search: ic('<circle cx="10.8" cy="10.8" r="6.3"/><path d="m15.4 15.4 4.1 4.1"/>'),
  gear: ic('<path d="M4 7.5h10M18 7.5h2M4 16.5h2M10 16.5h10"/><circle cx="16" cy="7.5" r="2.3"/><circle cx="8" cy="16.5" r="2.3"/>'),
  back: ic('<path d="M14.5 5.5 8 12l6.5 6.5"/>'),
  repeat: ic('<path d="M4.6 11.2a7.4 7.4 0 0 1 12.8-4.6l2 2"/><path d="M19.4 12.8a7.4 7.4 0 0 1-12.8 4.6l-2-2"/><path d="M19.4 4.2v4.4H15"/><path d="M4.6 19.8v-4.4H9"/>'),
  target: ic('<circle cx="12" cy="12" r="7.6"/><circle cx="12" cy="12" r="3.2"/>'),
  plus: ic('<path d="M12 5.4v13.2M5.4 12h13.2"/>'),
  flag: ic('<path d="M6 21V4.4h11.6l-2.2 4 2.2 4H6"/>'),
  cross: ic('<path d="M6.8 6.8 17.2 17.2M17.2 6.8 6.8 17.2"/>')
};


var DOM_BY_ID = {}, SEC_TITLE = {}, DOM_QS = {}, SEC_QS = {}, DOM_CARDS = {}, Q_BY_ID = {}, C_BY_ID = {};
DOMAINS.forEach(function (d) {
  DOM_BY_ID[d.id] = d; DOM_QS[d.id] = []; DOM_CARDS[d.id] = [];
  d.secs.forEach(function (s) { SEC_TITLE[d.id + "/" + s.id] = s.t; SEC_QS[d.id + "/" + s.id] = []; });
});
QS.forEach(function (q) {
  Q_BY_ID[q.i] = q; DOM_QS[q.d].push(q);
  var k = q.d + "/" + q.s; if (SEC_QS[k]) SEC_QS[k].push(q);
});
CARDS.forEach(function (c) { C_BY_ID[c.i] = c; if (DOM_CARDS[c.d]) DOM_CARDS[c.d].push(c); });

var Q_IVL = [0, 1, 3, 7, 16, 35];       // Leitner intervals (days) by box
var MASTER_BOX = 3;                      // box at which a question counts as mastered

/* ------------------------------------------------------------- storage */
var KEY = "cissp_drill_v1";
var hasLS = false;
try { localStorage.setItem("__p", "1"); localStorage.removeItem("__p"); hasLS = true; } catch (e) {}
var hasWS = !!(window.storage && typeof window.storage.get === "function");

var SCHEMA = 2;
var S = null;
function blank() {
  return { v: SCHEMA, q: {}, c: {}, read: {}, sess: [], hist: {}, flagQ: [], flagC: [], mock: null,
           set: { theme: "dark", examDate: "", goal: 20, timer: 1, sound: 0 } };
}

/* v1 keyed progress by a hash of the question text, so fixing a typo silently
   wiped that question's history. v2 uses permanent IDs; DATA.mig translates the
   old keys across once, so nobody loses anything on the upgrade. */
function migrateIds(o) {
  var map = DATA.mig || {}, moved = 0;
  function remapDict(src) {
    var out = {}, k;
    for (k in src) {
      if (!src.hasOwnProperty(k)) continue;
      var nk = map[k];
      if (nk) { moved++; if (!out[nk]) out[nk] = src[k]; }
      else out[k] = src[k];
    }
    return out;
  }
  function remapList(arr) {
    if (!arr || !arr.length) return arr || [];
    var out = [], i;
    for (i = 0; i < arr.length; i++) out.push(map[arr[i]] || arr[i]);
    return out;
  }
  o.q = remapDict(o.q || {});
  o.c = remapDict(o.c || {});
  o.flagQ = remapList(o.flagQ);
  o.flagC = remapList(o.flagC);
  if (o.mock && o.mock.ids) o.mock.ids = remapList(o.mock.ids);
  return moved;
}

var MIGRATED = 0;
function migrate(o) {
  var b = blank(), k;
  for (k in b) if (!(k in o)) o[k] = b[k];
  for (k in b.set) if (!(k in o.set)) o.set[k] = b.set[k];
  if (!o.v || o.v < 2) { MIGRATED += migrateIds(o); o.v = 2; }
  if (o.v !== SCHEMA) { MIGRATED++; o.v = SCHEMA; }
  return o;
}
function loadState() {
  return new Promise(function (res) {
    var raw = null;
    if (hasLS) { try { raw = localStorage.getItem(KEY); } catch (e) {} }
    if (raw) { try { return res(migrate(JSON.parse(raw))); } catch (e) {} }
    if (hasWS) {
      window.storage.get(KEY).then(function (r) {
        if (r && r.value) { try { return res(migrate(JSON.parse(r.value))); } catch (e) {} }
        res(blank());
      })["catch"](function () { res(blank()); });
      return;
    }
    res(blank());
  });
}
var saveT = null, storageOK = true;
function save() {
  if (saveT) clearTimeout(saveT);
  saveT = setTimeout(function () {
    var raw;
    try { raw = JSON.stringify(S); } catch (e) { return; }
    if (hasLS) {
      try { localStorage.setItem(KEY, raw); }
      catch (e) { if (storageOK) { storageOK = false; toast("保存領域が一杯です。設定からバックアップを書き出してください"); } }
    }
    if (hasWS) { try { window.storage.set(KEY, raw)["catch"](function () {}); } catch (e) {} }
  }, 260);
}
function saveNow() { if (saveT) clearTimeout(saveT); saveT = null;
  var raw; try { raw = JSON.stringify(S); } catch (e) { return; }
  if (hasLS) { try { localStorage.setItem(KEY, raw); } catch (e) {} }
  if (hasWS) { try { window.storage.set(KEY, raw)["catch"](function () {}); } catch (e) {} }
}

/* --------------------------------------------------------------- utils */
function $(s, r) { return (r || document).querySelector(s); }
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) {
  return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]; }); }
function pad(n) { return n < 10 ? "0" + n : "" + n; }
function today() { var d = new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
function dayNum(str) { var p = (str || today()).split("-"); return Math.floor(Date.UTC(+p[0], +p[1] - 1, +p[2]) / 86400000); }
function fromDay(n) { var d = new Date(n * 86400000); return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()); }
function TODAY() { return dayNum(today()); }
function pct(x) { return Math.round(x * 100); }
function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function mmss(s) { s = Math.max(0, Math.round(s)); var m = Math.floor(s / 60); return pad(m) + ":" + pad(s % 60); }
function hhmm(s) { s = Math.max(0, Math.round(s)); var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
  return h > 0 ? h + ":" + pad(m) + ":" + pad(s % 60) : pad(m) + ":" + pad(s % 60); }

var toastT = null;
function toast(msg) {
  var el = $("#toast"); el.textContent = msg; el.classList.add("on");
  if (toastT) clearTimeout(toastT);
  toastT = setTimeout(function () { el.classList.remove("on"); }, 2200);
}
function haptic() { if (navigator.vibrate) { try { navigator.vibrate(8); } catch (e) {} } }

var modalCB = null;
function confirmBox(title, body, okLabel, cb, danger) {
  modalCB = cb;
  $("#modal").innerHTML =
    '<div class="box"><h3>' + esc(title) + "</h3><p>" + body + '</p>' +
    '<div class="stack"><button class="btn' + (danger ? " danger" : "") + '" data-mok>' + esc(okLabel) + "</button>" +
    '<button class="btn quiet" data-mno>キャンセル</button></div></div>';
  $("#modal").classList.add("on");
}
function closeModal() { $("#modal").classList.remove("on"); modalCB = null; }

/* ------------------------------------------------------------ progress */
function qrec(id) { var r = S.q[id]; if (!r) { r = S.q[id] = { n: 0, c: 0, box: 0, due: 0, last: 0, ms: 0 }; } return r; }
function crec(id) { var r = S.c[id]; if (!r) { r = S.c[id] = { n: 0, box: 0, ease: 2.5, ivl: 0, due: 0, lapse: 0 }; } return r; }

function qScore(q) {
  var r = S.q[q.i];
  if (!r || !r.n) return 0;
  return Math.min(1, r.box / MASTER_BOX);
}
function sectionMastery(dId, sId) {
  var list = SEC_QS[dId + "/" + sId] || [];
  if (!list.length) return { m: 0, n: 0, seen: 0 };
  var sum = 0, seen = 0;
  list.forEach(function (q) { sum += qScore(q); if (S.q[q.i] && S.q[q.i].n) seen++; });
  return { m: sum / list.length, n: list.length, seen: seen };
}
function domainMastery(dId) {
  var list = DOM_QS[dId];
  if (!list.length) return { m: 0, n: 0, seen: 0, acc: 0 };
  var sum = 0, seen = 0, att = 0, cor = 0;
  list.forEach(function (q) {
    sum += qScore(q);
    var r = S.q[q.i];
    if (r && r.n) { seen++; att += r.n; cor += r.c; }
  });
  return { m: sum / list.length, n: list.length, seen: seen, acc: att ? cor / att : 0 };
}
function readiness() {
  var tot = 0, wt = 0;
  DOMAINS.forEach(function (d) { tot += domainMastery(d.id).m * d.w; wt += d.w; });
  return wt ? tot / wt : 0;
}
function cardStats() {
  var due = 0, learned = 0, isNew = 0, t = TODAY();
  CARDS.forEach(function (c) {
    var r = S.c[c.i];
    if (!r || !r.n) { isNew++; return; }
    if (r.due <= t) due++;
    if (r.ivl >= 7) learned++;
  });
  return { due: due, "new": isNew, learned: learned, total: CARDS.length };
}
function dueQuestions() {
  var t = TODAY(), out = [];
  QS.forEach(function (q) { var r = S.q[q.i]; if (r && r.n && r.due <= t) out.push(q); });
  return out;
}
function newQuestions() { return QS.filter(function (q) { return !S.q[q.i] || !S.q[q.i].n; }); }
function wrongQuestions() {
  return QS.filter(function (q) { var r = S.q[q.i]; return r && r.n && r.box < 2 && r.n > r.c; });
}
function weakSections() {
  var out = [];
  DOMAINS.forEach(function (d) {
    d.secs.forEach(function (s) {
      var m = sectionMastery(d.id, s.id);
      if (m.n >= 3 && m.seen >= 2 && m.m < 0.6) out.push({ d: d.id, s: s.id, t: s.t, dn: d.n, m: m.m, n: m.n, seen: m.seen });
    });
  });
  out.sort(function (a, b) { return a.m - b.m; });
  return out;
}

function todayRec() { var k = today(); if (!S.hist[k]) S.hist[k] = { q: 0, c: 0, card: 0, sec: 0 }; return S.hist[k]; }
function bumpStreakDays() {
  var keys = Object.keys(S.hist).filter(function (k) { var h = S.hist[k]; return h.q > 0 || h.card > 0 || h.sec > 0; });
  if (!keys.length) return 0;
  keys.sort();
  var t = TODAY(), last = dayNum(keys[keys.length - 1]);
  if (t - last > 1) return 0;
  var n = 0, cur = last, set = {};
  keys.forEach(function (k) { set[dayNum(k)] = 1; });
  while (set[cur]) { n++; cur--; }
  return n;
}

/* ------------------------------------------------------------ SRS core */
function gradeQuestion(q, correct, ms) {
  var r = qrec(q.i), t = TODAY();
  r.n++; if (correct) r.c++;
  r.ms += ms || 0;
  r.last = t;
  if (correct) { r.box = Math.min(5, r.box + 1); r.due = t + Q_IVL[r.box]; }
  else { r.box = 0; r.due = t; }
  var h = todayRec(); h.q++; if (correct) h.c++;
}
function gradeCard(c, g) {
  var r = crec(c.i), t = TODAY();
  r.n++;
  if (g === 0) {
    r.lapse++; r.ivl = 0; r.box = 0; r.due = t;
    r.ease = clamp(r.ease - 0.2, 1.3, 2.8);
  } else {
    r.box = Math.min(8, r.box + 1);
    if (r.box <= 1) r.ivl = (g === 1 ? 1 : g === 2 ? 2 : 4);
    else if (r.box === 2) r.ivl = (g === 1 ? 3 : g === 2 ? 6 : 10);
    else r.ivl = Math.max(1, Math.round(r.ivl * r.ease * (g === 1 ? 0.65 : g === 2 ? 1 : 1.35)));
    r.ease = clamp(r.ease + (g - 2) * 0.1, 1.3, 2.8);
    r.due = t + r.ivl;
  }
  todayRec().card++;
}

/* ------------------------------------------------------------ octagon */
function polar(cx, cy, r, deg) { var a = (deg - 90) * Math.PI / 180; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; }
function sector(cx, cy, r0, r1, a0, a1) {
  var p0 = polar(cx, cy, r1, a0), p1 = polar(cx, cy, r1, a1),
      p2 = polar(cx, cy, r0, a1), p3 = polar(cx, cy, r0, a0),
      lg = (a1 - a0) > 180 ? 1 : 0;
  return "M" + p0[0].toFixed(2) + " " + p0[1].toFixed(2) +
         "A" + r1 + " " + r1 + " 0 " + lg + " 1 " + p1[0].toFixed(2) + " " + p1[1].toFixed(2) +
         "L" + p2[0].toFixed(2) + " " + p2[1].toFixed(2) +
         "A" + r0 + " " + r0 + " 0 " + lg + " 0 " + p3[0].toFixed(2) + " " + p3[1].toFixed(2) + "Z";
}
function octagon(interactive) {
  var C = 130, R0 = 56, R1 = 118, GAP = 1.6, ang = -90 + 90, cur = 0, out = "";
  cur = 0;
  DOMAINS.forEach(function (d) {
    var span = d.w / 100 * 360;
    var a0 = cur + GAP / 2, a1 = cur + span - GAP / 2;
    var m = domainMastery(d.id).m;
    var rf = R0 + (R1 - R0) * Math.max(m, 0.012);
    var mid = (a0 + a1) / 2, lp = polar(C, C, R1 + 13, mid);
    out += '<path class="seg" d="' + sector(C, C, R0, R1, a0, a1) + '" fill="var(--panel3)" opacity=".42"/>';
    out += '<path class="fill" d="' + sector(C, C, R0, rf, a0, a1) + '" fill="' + DCOLOR[d.id] + '" opacity=".92"/>';
    out += '<text x="' + lp[0].toFixed(1) + '" y="' + (lp[1] + 4).toFixed(1) + '" text-anchor="middle" ' +
           'font-size="16" font-weight="700" fill="' + DCOLOR[d.id] + '">' + d.n + "</text>";
    if (interactive) out += '<path d="' + sector(C, C, R0 - 4, R1 + 6, a0, a1) + '" fill="transparent" data-go="dom" data-d="' + d.id + '" style="cursor:pointer"/>';
    cur += span;
  });
  return '<svg class="octa" viewBox="0 0 260 260" aria-hidden="true">' + out + "</svg>";
}
function ringSvg(p, color) {
  var r = 68, c = 2 * Math.PI * r;
  return '<svg viewBox="0 0 170 170"><circle cx="85" cy="85" r="' + r + '" fill="none" stroke="var(--panel3)" stroke-width="12"/>' +
    '<circle cx="85" cy="85" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="12" stroke-linecap="round" ' +
    'stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + (c * (1 - p)).toFixed(1) + '" transform="rotate(-90 85 85)"/></svg>';
}

/* --------------------------------------------------------------- views */
var route = { name: "home", p: {} }, stack = [];
var TABS = [
  { id: "home",  ic: ICON.today, label: "今日" },
  { id: "drill", ic: ICON.drill, label: "演習" },
  { id: "cards", ic: ICON.cards, label: "暗記" },
  { id: "read",  ic: ICON.read,  label: "教科書" },
  { id: "stats", ic: ICON.stats, label: "記録" }
];
var TAB_OF = { home:"home", drill:"drill", quiz:"drill", result:"drill",
               cards:"cards", cardrun:"cards", recall:"cards",
               read:"read", readdom:"read", readsec:"read", cheat:"read", cheatone:"read", search:"read",
               stats:"stats", settings:"stats" };

function go(name, p, replace) {
  if (!replace && route.name !== name) stack.push({ name: route.name, p: route.p });
  route = { name: name, p: p || {} };
  render();
  window.scrollTo(0, 0);
}
function back() {
  var prev = stack.pop();
  route = prev || { name: "home", p: {} };
  render(); window.scrollTo(0, 0);
}
function tabGo(id) { stack = []; route = { name: id, p: {} }; render(); window.scrollTo(0, 0); }

function render() {
  var v = VIEWS[route.name];
  if (!v) { route = { name: "home", p: {} }; v = VIEWS.home; }
  var out = v(route.p);
  $("#bar").innerHTML = out.bar;
  var m = $("#view");
  m.className = out.full ? "full fade" : "fade";
  m.innerHTML = out.html;
  var tb = $("#tabbar");
  tb.classList.toggle("hide", !!out.hideTabs);
  var active = TAB_OF[route.name] || "home";
  Array.prototype.forEach.call(tb.children, function (b) { b.classList.toggle("on", b.dataset.tab === active); });
  if (out.after) out.after();
}
function barTitle(title, sub, withBack, right) {
  return '<div class="appbar-in">' +
    (withBack ? '<button class="iconbtn" data-back aria-label="戻る">' + ICON.back + "</button>" : "") +
    "<h1>" + esc(title) + (sub ? '<span class="sub">' + esc(sub) + "</span>" : "") + "</h1>" +
    (right || "") + "</div>";
}

/* ==================================================== VIEW: today ===== */
function planItems() {
  var t = TODAY(), items = [];
  var due = dueQuestions(), nw = newQuestions(), cs = cardStats(), weak = weakSections();
  // The badge is the size of the backlog; the sub-line says how much one round covers.
  if (due.length) items.push({ k: "due", ic: ICON.repeat, c: "var(--kin)", cw: "var(--kin-w)", t: "復習の期限が来た問題",
    s: "1回 " + Math.min(20, due.length) + " 問ずつ — 間隔をあけるほど定着します", n: due.length });
  if (weak.length) items.push({ k: "weak", ic: ICON.target, c: "var(--shu)", cw: "var(--shu-w)", t: "弱点セクションを集中",
    s: weak[0].t + (weak.length > 1 ? " ほか " + (weak.length - 1) + " 節" : "") + " から 15 問", n: weak.length });
  if (cs.due + cs["new"] > 0) items.push({ k: "card", ic: ICON.cards, c: "var(--matsu)", cw: "var(--matsu-w)", t: "単語カード",
    s: "復習 " + cs.due + " 枚 / 未学習 " + cs["new"] + " 枚 — 1回 " + Math.min(30, cs.due + cs["new"]) + " 枚",
    n: cs.due + cs["new"] });
  if (nw.length) items.push({ k: "new", ic: ICON.plus, c: "var(--ai)", cw: "var(--ai-w)", t: "新しい問題に挑戦",
    s: "未着手 " + nw.length + " 問 — 遅れているドメインから 10 問", n: nw.length });
  return items;
}

/* ==================================================== the view table == */
var VIEWS = {};

VIEWS.home = function () {
  var rd = readiness(), streak = bumpStreakDays(), h = todayRec(), goal = S.set.goal || 20;
  var items = planItems();
  var examDays = null;
  if (S.set.examDate) { var d = dayNum(S.set.examDate) - TODAY(); examDays = d; }
  var attempted = 0, correct = 0;
  QS.forEach(function (q) { var r = S.q[q.i]; if (r && r.n) { attempted += r.n; correct += r.c; } });
  var seen = QS.filter(function (q) { return S.q[q.i] && S.q[q.i].n; }).length;

  var wk = "";
  for (var i = 6; i >= 0; i--) {
    var k = fromDay(TODAY() - i), rec = S.hist[k];
    var on = rec && (rec.q > 0 || rec.card > 0 || rec.sec > 0);
    var lbl = "日月火水木金土"[new Date(k + "T00:00:00").getDay()];
    wk += '<i class="' + (on ? "on " : "") + (i === 0 ? "today" : "") + '">' + lbl + "</i>";
  }

  var rcol = rd < .4 ? "var(--shu)" : rd < .7 ? "var(--kin)" : "var(--matsu)";
  var html =
    '<div class="hero">' +
      '<div class="octa-wrap" style="flex:0 0 auto">' + octagon(true) +
        '<div class="octa-c"><span class="big" style="color:' + rcol + '">' + pct(rd) + "</span>" +
        '<span class="cap">到達度</span></div>' +
      "</div>" +
      '<div class="info"><span class="d1" style="font:600 11px/1 var(--sans);letter-spacing:.14em;color:var(--dim)">READINESS</span>' +
        '<span class="d2 disp" style="font-size:18px;font-weight:600;margin-top:7px;display:block;line-height:1.5">' +
          (rd < .25 ? "土台づくり" : rd < .5 ? "積み上げ中" : rd < .75 ? "仕上げ段階" : "合格圏内") + "</span>" +
        (examDays !== null ? '<div class="countdown" style="text-align:left;margin-top:12px;display:inline-block"><span class="n">' +
          (examDays >= 0 ? examDays : "—") + '</span><span class="l">' + (examDays >= 0 ? "DAYS LEFT" : "経過") + "</span></div>" : "") +
      "</div>" +
    "</div>" +

    '<div class="streak"><span class="fl">' + (streak > 0 ? "🔥" : "◇") + '</span><div><div class="n">' + streak +
      '<span style="font-size:13px;font-weight:600;color:var(--dim)"> 日連続</span></div>' +
      '<div class="l">今日 ' + h.q + " / " + goal + " 問</div></div>" +
      '<div class="week">' + wk + "</div></div>" +

    '<h2 class="sec">今日やること</h2>' +
    (items.length ? '<div class="plan">' + items.map(function (it) {
      return '<button class="p" style="--c:' + it.c + ';--cw:' + it.cw + '" data-plan="' + it.k + '">' +
        '<span class="ic">' + it.ic + '</span><span class="tx"><b>' + esc(it.t) + "</b><span>" + esc(it.s) + "</span></span>" +
        '<span class="cnt">' + it.n + "</span></button>";
    }).join("") + "</div>"
    : '<div class="card center"><b style="display:block;margin-bottom:6px">今日の予定は消化済みです</b><span class="tiny mut">明日また復習が出てきます。模擬試験で総合力を確かめてもよい頃合いです。</span></div>') +

    '<div class="stack" style="margin-top:14px">' +
      '<button class="btn" data-go="quiz" data-mode="quick">10問クイック演習</button>' +
      '<button class="btn ghost" data-go="drill">演習メニューを開く</button>' +
    "</div>" +

    '<h2 class="sec">ドメイン別の到達度</h2>' +
    '<div class="card tight"><div class="legend">' + DOMAINS.map(function (d) {
      var m = domainMastery(d.id);
      return '<button data-go="dom" data-d="' + d.id + '"><span class="swatch" style="background:' + DCOLOR[d.id] + '"></span>' +
        '<span class="nm">' + d.n + " " + esc(DSHORT[d.id]) + '</span><span class="pc" style="color:' + DCOLOR[d.id] + '">' + pct(m.m) + "</span></button>";
    }).join("") + "</div></div>" +

    '<h2 class="sec">現在地</h2>' +
    '<div class="kpis">' +
      '<div class="kpi"><span class="n">' + seen + '<span style="font-size:13px;color:var(--dim)">/' + QS.length + '</span></span><span class="l">着手した問題</span></div>' +
      '<div class="kpi"><span class="n">' + (attempted ? pct(correct / attempted) : 0) + '<span style="font-size:13px;color:var(--dim)">%</span></span><span class="l">通算正答率</span></div>' +
      '<div class="kpi"><span class="n">' + cardStats().learned + '<span style="font-size:13px;color:var(--dim)">/' + CARDS.length + '</span></span><span class="l">定着カード</span></div>' +
    "</div>";

  return { bar: barTitle("CISSP 演習帳", "自己学習ドリル", false,
      '<button class="iconbtn" data-go="search" aria-label="検索">' + ICON.search + "</button>" +
      '<button class="iconbtn" data-go="settings" aria-label="設定">' + ICON.gear + "</button>"), html: html };
};

/* ==================================================== VIEW: drill ===== */
VIEWS.drill = function () {
  var due = dueQuestions().length, nw = newQuestions().length, wrong = wrongQuestions().length,
      flag = S.flagQ.length, weak = weakSections().length;
  var mock = S.mock;
  var html =
    (mock ? '<div class="card" style="border-color:var(--kin)"><div class="row"><div class="sp">' +
      '<b style="display:block">中断中の模擬試験があります</b><span class="tiny mut">' + (mock.idx + 1) + " / " + mock.ids.length + " 問目 — 残り " + hhmm(mock.left) + "</span></div></div>" +
      '<div class="row" style="margin-top:12px;gap:8px"><button class="btn sm" style="flex:1" data-resume>再開する</button>' +
      '<button class="btn sm ghost" style="flex:0 0 auto" data-dropmock>破棄</button></div></div>' : "") +

    '<h2 class="sec">おすすめ</h2><div class="list">' +
      row(ICON.repeat, "復習（期限到来）", "間隔反復のスケジュールに従う", due, ["quiz", { mode: "due" }], due === 0) +
      row(ICON.target, "弱点集中", "正答率の低いセクションから出題", weak, ["quiz", { mode: "weak" }], weak === 0) +
      row(ICON.plus, "新規問題", "まだ解いていない問題", nw, ["quiz", { mode: "new" }], nw === 0) +
      row(ICON.cross, "間違えた問題", "直近で不正解・未定着のもの", wrong, ["quiz", { mode: "wrong" }], wrong === 0) +
      row(ICON.flag, "フラグを付けた問題", "後で見直すと決めたもの", flag, ["quiz", { mode: "flag" }], flag === 0) +
    "</div>" +

    '<h2 class="sec">ドメイン別</h2><div class="list">' +
      DOMAINS.map(function (d) {
        var m = domainMastery(d.id);
        return '<button class="li" data-go="dom" data-d="' + d.id + '">' +
          '<span class="mk" style="background:' + DCOLOR[d.id] + '22;color:' + DCOLOR[d.id] + '">' + d.n + "</span>" +
          '<span class="lead"><span class="t">' + esc(d.t) + '</span><span class="s">' + m.n + " 問 ・ 到達度 " + pct(m.m) + "% ・ 出題比率 " + d.w + "%</span></span>" +
          '<span class="arw">›</span></button>';
      }).join("") + "</div>" +

    '<h2 class="sec">模擬試験</h2>' +
    '<div class="card tight"><p class="tiny mut" style="margin:0 0 12px">出題比率どおりにドメインを配分し、途中で正誤は表示しません。本番と同じく「最も適切なもの」を選ぶ判断力を測ります。</p>' +
      '<div class="stack">' +
      '<button class="btn ghost" data-mock="50">50問 ・ 60分</button>' +
      '<button class="btn ghost" data-mock="100">100問 ・ 120分</button>' +
      '<button class="btn ghost" data-mock="125">125問 ・ 150分（本番相当）</button>' +
      "</div></div>" +
    '<div style="height:8px"></div>';

  function row(ic, t, s, n, target, off) {
    return '<button class="li"' + (off ? ' disabled style="opacity:.45"' : "") +
      ' data-go="' + target[0] + '" data-mode="' + target[1].mode + '">' +
      '<span class="mk">' + ic + "</span>" +
      '<span class="lead"><span class="t">' + t + '</span><span class="s">' + s + "</span></span>" +
      '<span class="tagpill' + (n ? "" : " n") + '">' + n + "</span></button>";
  }
  return { bar: barTitle("演習", QS.length + " 問を収録"), html: html };
};

/* --------------------------------------------------- domain sub-menu */
VIEWS.dom = function (p) {
  var d = DOM_BY_ID[p.d], m = domainMastery(d.id);
  var html =
    '<div class="card"><div class="row"><div class="sp">' +
      '<span class="tiny dimt">DOMAIN ' + d.n + " ・ 出題比率 " + d.w + '%</span>' +
      '<div style="font-family:var(--disp);font-size:19px;font-weight:600;margin-top:4px">' + esc(d.t) + "</div>" +
      '<div class="tiny mut" style="margin-top:2px">' + esc(d.en) + "</div></div>" +
      '<div style="text-align:right;flex:0 0 auto"><div class="num" style="font-size:26px;font-weight:700;color:' + DCOLOR[d.id] + '">' + pct(m.m) + "</div>" +
      '<div class="tiny dimt">到達度</div></div></div>' +
      '<div class="bar" style="margin-top:14px"><i style="width:' + pct(m.m) + "%;background:" + DCOLOR[d.id] + '"></i></div>' +
      '<div class="tiny dimt" style="margin-top:8px">' + m.seen + " / " + m.n + " 問に着手" + (m.seen ? " ・ 正答率 " + pct(m.acc) + "%" : "") + "</div></div>" +

    '<div class="stack">' +
      '<button class="btn" data-go="quiz" data-mode="dom" data-d="' + d.id + '">このドメインを演習</button>' +
      '<button class="btn ghost" data-go="readdom" data-d="' + d.id + '">教科書を読む</button>' +
      '<button class="btn ghost" data-go="cardrun" data-mode="dom" data-d="' + d.id + '">単語カード（' + DOM_CARDS[d.id].length + "枚）</button>" +
    "</div>" +

    '<h2 class="sec">セクション別の到達度</h2><div class="list">' +
      d.secs.filter(function (s) { return (SEC_QS[d.id + "/" + s.id] || []).length > 0; }).map(function (s) {
        var sm = sectionMastery(d.id, s.id);
        var col = sm.m < .35 ? "var(--shu)" : sm.m < .7 ? "var(--kin)" : "var(--matsu)";
        return '<button class="li" data-go="quiz" data-mode="sec" data-d="' + d.id + '" data-s="' + s.id + '">' +
          '<span class="lead"><span class="t">' + esc(s.t) + '</span>' +
          '<span class="s">' + sm.seen + " / " + sm.n + " 問に着手</span>" +
          '<span class="bar" style="margin-top:7px"><i style="width:' + pct(sm.m) + "%;background:" + col + '"></i></span></span>' +
          '<span class="pc num" style="color:' + col + ';font-weight:700;font-size:13px;width:36px;text-align:right">' + pct(sm.m) + "</span></button>";
      }).join("") + "</div>";
  return { bar: barTitle("Domain " + d.n, d.t, true), html: html };
};

/* ==================================================== quiz engine ===== */
var Q = null;
function buildQuiz(p) {
  var pool = [], limit = 10, label = "演習", timed = 0, mock = false;
  var t = TODAY();
  if (p.mode === "due")      { pool = shuffle(dueQuestions()); limit = Math.min(20, pool.length); label = "復習"; }
  else if (p.mode === "new") { pool = pickNew(10); limit = pool.length; label = "新規問題"; }
  else if (p.mode === "wrong") { pool = shuffle(wrongQuestions()); limit = Math.min(20, pool.length); label = "間違えた問題"; }
  else if (p.mode === "flag")  { pool = shuffle(S.flagQ.map(function (i) { return Q_BY_ID[i]; }).filter(Boolean)); limit = pool.length; label = "フラグ"; }
  else if (p.mode === "weak")  {
    var ws = weakSections().slice(0, 5), seen = {};
    ws.forEach(function (w) { (SEC_QS[w.d + "/" + w.s] || []).forEach(function (q) { if (!seen[q.i]) { seen[q.i] = 1; pool.push(q); } }); });
    pool.sort(function (a, b) { return qScore(a) - qScore(b); });
    pool = pool.slice(0, 40); pool = shuffle(pool); limit = Math.min(15, pool.length); label = "弱点集中";
  }
  else if (p.mode === "dom")  { pool = orderForStudy(DOM_QS[p.d]); limit = Math.min(15, pool.length); label = "Domain " + DOM_BY_ID[p.d].n; }
  else if (p.mode === "sec")  { pool = orderForStudy(SEC_QS[p.d + "/" + p.s]); limit = pool.length; label = SEC_TITLE[p.d + "/" + p.s]; }
  else if (p.mode === "mock") {
    pool = mockPool(p.n); limit = pool.length; label = p.n + "問 模擬試験"; timed = p.n * 72; mock = true;
  }
  else { pool = orderForStudy(QS); limit = 10; label = "クイック演習"; }

  var list = pool.slice(0, limit);
  if (!list.length) { toast("対象の問題がありません"); return null; }
  return {
    ids: list.map(function (q) { return q.i; }),
    idx: 0, ans: [], order: list.map(function (q) { return shuffle(q.o.map(function (_, i) { return i; })); }),
    label: label, mock: mock, left: timed, t0: Date.now(), qt0: Date.now(), picked: -1, locked: false, correct: 0
  };
}
function orderForStudy(list) {
  // unseen first (by lowest coverage), then lowest box, then random
  var a = list.slice();
  a.sort(function (x, y) {
    var rx = S.q[x.i], ry = S.q[y.i];
    var sx = rx && rx.n ? rx.box + 1 : 0, sy = ry && ry.n ? ry.box + 1 : 0;
    if (sx !== sy) return sx - sy;
    return Math.random() - .5;
  });
  return a;
}
function pickNew(n) {
  var nw = newQuestions();
  if (!nw.length) return [];
  // allocate by exam weight, favouring domains that are behind
  var byD = {}; nw.forEach(function (q) { (byD[q.d] = byD[q.d] || []).push(q); });
  var order = DOMAINS.slice().sort(function (a, b) {
    return (domainMastery(a.id).m / (a.w / 100)) - (domainMastery(b.id).m / (b.w / 100));
  });
  var out = [], i = 0;
  while (out.length < n && i < 200) {
    var d = order[i % order.length];
    if (byD[d.id] && byD[d.id].length) out.push(byD[d.id].shift());
    i++;
    if (!order.some(function (x) { return byD[x.id] && byD[x.id].length; })) break;
  }
  return out;
}
function mockPool(n) {
  var out = [];
  DOMAINS.forEach(function (d) {
    var k = Math.round(n * d.w / 100);
    var pool = shuffle(DOM_QS[d.id]);
    // prefer level 2-3 for realism, then fill
    var hard = pool.filter(function (q) { return q.l >= 2; }), easy = pool.filter(function (q) { return q.l < 2; });
    out = out.concat(hard.concat(easy).slice(0, k));
  });
  return shuffle(out).slice(0, n);
}

VIEWS.quiz = function (p) {
  if (!Q || Q.__p !== JSON.stringify(p)) {
    if (p.resume && S.mock) { Q = S.mock; Q.__p = JSON.stringify(p); }
    else {
      var q = buildQuiz(p);
      if (!q) { setTimeout(function () { back(); }, 0); return { bar: barTitle("演習", "", true), html: "" }; }
      Q = q; Q.__p = JSON.stringify(p);
      if (Q.mock) { S.mock = Q; save(); }
    }
  }
  return renderQuiz();
};

function renderQuiz() {
  var q = Q_BY_ID[Q.ids[Q.idx]], ord = Q.order[Q.idx];
  var d = DOM_BY_ID[q.d], flagged = S.flagQ.indexOf(q.i) >= 0;
  var lvl = ["", "基礎", "標準", "応用"][q.l] || "標準";
  var rec = S.q[q.i];

  var opts = ord.map(function (oi, pos) {
    var cls = "opt", mark = "";
    if (Q.locked) {
      if (oi === q.a) { cls += " ok"; mark = "✓"; }
      else if (pos === Q.picked) { cls += " ng"; mark = "✕"; }
      else cls += " mute";
    } else if (pos === Q.picked) cls += " pick";
    return '<button class="' + cls + '" data-opt="' + pos + '">' +
      '<span class="k">' + "ABCD"[pos] + '</span><span class="tx">' + esc(q.o[oi]) + "</span>" +
      '<span class="mark">' + mark + "</span></button>";
  }).join("");

  var verdict = "", expl = "";
  if (Q.locked && !Q.mock) {
    var ok = ord[Q.picked] === q.a;
    verdict = '<div class="verdict ' + (ok ? "ok" : "ng") + '"><span class="ic">' + (ok ? "✓" : "✕") + "</span>" +
      (ok ? "正解" : "不正解 — 正答は " + "ABCD"[ord.indexOf(q.a)]) + "</div>";
    expl = '<div class="expl"><span class="lab">解説</span>' + q.e +
      '<div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap">' +
      '<button class="btn sm quiet" data-go="readsec" data-d="' + q.d + '" data-s="' + q.s + '">📖 ' + esc(SEC_TITLE[q.d + "/" + q.s] || "解説を読む") + "</button></div></div>";
  }

  var timerHtml = "";
  if (Q.mock) {
    var cls = Q.left < 300 ? " crit" : Q.left < 900 ? " warn" : "";
    timerHtml = '<span class="timer' + cls + '" id="timer">' + hhmm(Q.left) + "</span>";
  }

  var html =
    '<div class="qprog"><div class="qbar"><i style="width:' + ((Q.idx) / Q.ids.length * 100) + '%"></i></div>' +
      '<div class="qmeta"><span class="num">' + (Q.idx + 1) + " / " + Q.ids.length + "</span>" +
      (Q.mock ? "" : '<span>・ 正解 ' + Q.correct + "</span>") +
      '<span class="sp"></span>' + timerHtml + "</div></div>" +

    '<div class="qtags">' +
      '<span class="tagpill" style="background:' + DCOLOR[q.d] + '1f;color:' + DCOLOR[q.d] + '">D' + d.n + " " + esc(d.t) + "</span>" +
      '<span class="tagpill n">' + esc(SEC_TITLE[q.d + "/" + q.s] || "") + "</span>" +
      '<span class="tagpill ' + (q.l === 3 ? "s" : q.l === 2 ? "k" : "n") + '">' + lvl + "</span>" +
      (rec && rec.n ? '<span class="tagpill ' + (rec.box >= MASTER_BOX ? "m" : "n") + '">' + rec.c + "/" + rec.n + "</span>" : "") +
    "</div>" +

    '<div class="qstem">' + esc(q.q) + "</div>" +
    '<div class="opts' + (Q.locked ? " locked" : "") + '">' + opts + "</div>" +
    verdict + expl +

    '<div class="qfoot">' +
      '<button class="btn ghost icon" data-flag aria-label="フラグ" style="color:' + (flagged ? "var(--kin)" : "var(--muted)") + '">' + ICON.flag + "</button>" +
      (Q.locked || Q.mock
        ? '<button class="btn" data-next' + (!Q.locked && Q.picked < 0 ? " disabled" : "") + '>' + (Q.idx === Q.ids.length - 1 ? "採点する" : "次の問題 →") + "</button>"
        : '<button class="btn" data-check' + (Q.picked < 0 ? " disabled" : "") + ">解答する</button>") +
    "</div>";

  return {
    bar: barTitle(Q.label, (Q.mock ? "模擬試験" : "演習中"), false,
      '<button class="iconbtn wide" data-quit>中断</button>'),
    html: html, hideTabs: true, full: true, after: startTimer
  };
}

var tick = null;
function startTimer() {
  if (tick) { clearInterval(tick); tick = null; }
  if (!Q || !Q.mock) return;
  tick = setInterval(function () {
    if (!Q || !Q.mock) { clearInterval(tick); tick = null; return; }
    Q.left--;
    var el = document.getElementById("timer");
    if (el) {
      el.textContent = hhmm(Q.left);
      el.className = "timer" + (Q.left < 300 ? " crit" : Q.left < 900 ? " warn" : "");
    }
    if (Q.left % 10 === 0) { S.mock = Q; save(); }
    if (Q.left <= 0) { clearInterval(tick); tick = null; finishQuiz(true); }
  }, 1000);
}
function stopTimer() { if (tick) { clearInterval(tick); tick = null; } }

function checkAnswer() {
  if (Q.locked || Q.picked < 0) return;
  var q = Q_BY_ID[Q.ids[Q.idx]], ord = Q.order[Q.idx];
  var ok = ord[Q.picked] === q.a;
  Q.locked = true;
  Q.ans[Q.idx] = { pick: ord[Q.picked], ok: ok };
  if (ok) Q.correct++;
  gradeQuestion(q, ok, Date.now() - Q.qt0);
  save(); haptic();
  render();
  setTimeout(function () {
    var v = $(".verdict"); if (v && v.scrollIntoView) v.scrollIntoView({ behavior: "smooth", block: "center" });
  }, 60);
}
function nextQuestion() {
  if (Q.mock) {
    if (Q.picked < 0) return;
    var q = Q_BY_ID[Q.ids[Q.idx]], ord = Q.order[Q.idx];
    Q.ans[Q.idx] = { pick: ord[Q.picked], ok: ord[Q.picked] === q.a };
    if (Q.ans[Q.idx].ok) Q.correct++;
  }
  if (Q.idx >= Q.ids.length - 1) { finishQuiz(false); return; }
  Q.idx++; Q.picked = -1; Q.locked = false; Q.qt0 = Date.now();
  if (Q.mock) { S.mock = Q; save(); }
  render(); window.scrollTo(0, 0);
}
function finishQuiz(timeUp) {
  stopTimer();
  if (Q.mock) {
    // grade all at the end so SRS reflects the mock too
    Q.ids.forEach(function (id, i) {
      var a = Q.ans[i];
      if (a) gradeQuestion(Q_BY_ID[id], a.ok, 0);
    });
    S.mock = null;
  }
  S.sess.push({ ts: Date.now(), mode: Q.label, n: Q.ids.length, c: Q.correct,
                secs: Math.round((Date.now() - Q.t0) / 1000), mock: !!Q.mock });
  if (S.sess.length > 200) S.sess = S.sess.slice(-200);
  saveNow();
  var snap = Q; Q = null;
  RESULT = snap; RESULT.timeUp = timeUp;
  go("result", {}, true);
}
var RESULT = null;

VIEWS.result = function () {
  if (!RESULT) { setTimeout(function () { tabGo("drill"); }, 0); return { bar: "", html: "" }; }
  var R = RESULT, n = R.ids.length, c = R.correct, p = n ? c / n : 0;
  var col = p >= .8 ? "var(--matsu)" : p >= .6 ? "var(--kin)" : "var(--shu)";
  var msg = p >= .85 ? "本番でも通用する水準です" : p >= .7 ? "合格ラインが見えています" : p >= .5 ? "解説の読み込みで伸びます" : "まず教科書に戻りましょう";

  var byD = {};
  R.ids.forEach(function (id, i) {
    var q = Q_BY_ID[id], a = R.ans[i];
    if (!byD[q.d]) byD[q.d] = { n: 0, c: 0 };
    byD[q.d].n++; if (a && a.ok) byD[q.d].c++;
  });

  var wrongs = R.ids.map(function (id, i) { return { q: Q_BY_ID[id], a: R.ans[i] }; })
                    .filter(function (x) { return !x.a || !x.a.ok; });

  var html =
    (R.timeUp ? '<div class="card center" style="border-color:var(--shu)"><b style="color:var(--shu)">制限時間になりました</b></div>' : "") +
    '<div class="result-ring">' + ringSvg(p, col) +
      '<div class="mid"><div class="n" style="color:' + col + '">' + pct(p) + '<span style="font-size:20px">%</span></div>' +
      '<div class="l">' + c + " / " + n + " 問正解</div></div></div>" +
    '<div class="center disp" style="font-size:18px;margin:6px 0 4px">' + msg + "</div>" +
    '<div class="center tiny dimt">所要 ' + hhmm(Math.round((Date.now() - R.t0) / 1000)) + " ・ " + esc(R.label) + "</div>" +

    (Object.keys(byD).length > 1 ? '<h2 class="sec">ドメイン別</h2><div class="card">' +
      DOMAINS.filter(function (d) { return byD[d.id]; }).map(function (d) {
        var b = byD[d.id], pp = b.c / b.n;
        return '<div class="dbar"><span class="n">' + d.n + '</span><span class="nm">' + esc(DSHORT[d.id]) + "</span>" +
          '<span class="bar"><i style="width:' + pct(pp) + "%;background:" + (pp >= .7 ? "var(--matsu)" : pp >= .5 ? "var(--kin)" : "var(--shu)") + '"></i></span>' +
          '<span class="pc">' + b.c + "/" + b.n + "</span></div>";
      }).join("") + "</div>" : "") +

    (wrongs.length ? '<h2 class="sec">間違えた問題（' + wrongs.length + "）</h2>" +
      wrongs.map(function (x) {
        var q = x.q, picked = x.a ? q.o[x.a.pick] : null;
        return '<div class="card tight"><div class="rev"><div class="q">' + esc(q.q) + "</div>" +
          '<div class="a">' + (picked ? "<s>" + esc(picked) + "</s><br>" : "<span class='dimt'>無回答</span><br>") +
          "<em>正答： " + esc(q.o[q.a]) + "</em></div></div>" +
          '<div class="expl" style="margin-top:10px;animation:none"><span class="lab">解説</span>' + q.e + "</div>" +
          '<button class="btn sm quiet" style="margin-top:10px" data-go="readsec" data-d="' + q.d + '" data-s="' + q.s + '">📖 ' + esc(SEC_TITLE[q.d + "/" + q.s] || "") + "</button></div>";
      }).join("") : '<div class="card center"><b>全問正解です</b></div>') +

    '<div class="stack" style="margin-top:16px">' +
      '<button class="btn" data-go="drill">演習メニューへ</button>' +
      '<button class="btn ghost" data-go="home">今日の画面へ</button>' +
    "</div>";

  return { bar: barTitle("結果", esc(R.label)), html: html, hideTabs: false };
};

/* ==================================================== VIEW: cards ===== */
VIEWS.cards = function () {
  var cs = cardStats();
  var groups = {};
  CARDS.forEach(function (c) { var k = c.d; (groups[k] = groups[k] || []).push(c); });
  var html =
    '<div class="kpis"><div class="kpi"><span class="n" style="color:var(--kin)">' + cs.due + '</span><span class="l">復習期限</span></div>' +
    '<div class="kpi"><span class="n" style="color:var(--ai)">' + cs["new"] + '</span><span class="l">未学習</span></div>' +
    '<div class="kpi"><span class="n" style="color:var(--matsu)">' + cs.learned + '</span><span class="l">定着</span></div></div>' +

    '<div class="stack">' +
      '<button class="btn" data-go="cardrun" data-mode="mix"' + (cs.due + cs["new"] === 0 ? " disabled" : "") + ">今日の分を進める（" + Math.min(30, cs.due + cs["new"]) + "枚）</button>" +
      '<button class="btn ghost" data-go="recall">記述式で確認する（' + WRITTEN.length + "問)</button>" +
    "</div>" +

    '<h2 class="sec">ドメイン別</h2><div class="list">' +
      DOMAINS.map(function (d) {
        var list = groups[d.id] || [], t = TODAY();
        var due = list.filter(function (c) { var r = S.c[c.i]; return !r || !r.n || r.due <= t; }).length;
        return '<button class="li" data-go="cardrun" data-mode="dom" data-d="' + d.id + '">' +
          '<span class="mk" style="background:' + DCOLOR[d.id] + '22;color:' + DCOLOR[d.id] + '">' + d.n + "</span>" +
          '<span class="lead"><span class="t">' + esc(d.t) + '</span><span class="s">' + list.length + " 枚</span></span>" +
          '<span class="tagpill' + (due ? " k" : " m") + '">' + (due ? due + " 枚" : "完了") + "</span></button>";
      }).join("") + "</div>";
  return { bar: barTitle("単語カード", CARDS.length + " 枚を収録"), html: html };
};

var CR = null;
VIEWS.cardrun = function (p) {
  if (!CR || CR.__p !== JSON.stringify(p)) {
    var t = TODAY(), pool;
    if (p.mode === "dom") pool = DOM_CARDS[p.d].slice();
    else pool = CARDS.slice();
    var due = [], nw = [];
    pool.forEach(function (c) { var r = S.c[c.i]; if (!r || !r.n) nw.push(c); else if (r.due <= t) due.push(c); });
    var list = shuffle(due).concat(shuffle(nw)).slice(0, p.mode === "dom" ? 40 : 30);
    if (!list.length) { toast("このデッキは今日の分が終わっています"); setTimeout(back, 0); return { bar: "", html: "" }; }
    CR = { ids: list.map(function (c) { return c.i; }), idx: 0, show: false, done: 0, again: [], __p: JSON.stringify(p),
           label: p.mode === "dom" ? DOM_BY_ID[p.d].t : "今日のカード" };
  }
  if (CR.idx >= CR.ids.length) {
    if (CR.again.length) { CR.ids = CR.again; CR.again = []; CR.idx = 0; CR.show = false; }
    else {
      var n = CR.done; CR = null; saveNow();
      return { bar: barTitle("完了"), html:
        '<div class="empty"><div class="big">✓</div><b>' + n + ' 枚を確認しました</b><span class="tiny">忘れかけたタイミングで再び出てきます</span></div>' +
        '<div class="stack"><button class="btn" data-go="cards">カード一覧へ</button><button class="btn ghost" data-go="home">今日の画面へ</button></div>' };
    }
  }
  var c = C_BY_ID[CR.ids[CR.idx]], d = DOM_BY_ID[c.d], r = S.c[c.i];
  var isEn = /^[\x20-\x7E]+$/.test(c.f) && c.f.length < 60;
  var html =
    '<div class="qprog"><div class="qbar"><i style="width:' + (CR.idx / CR.ids.length * 100) + '%"></i></div>' +
      '<div class="qmeta"><span class="num">' + (CR.idx + 1) + " / " + CR.ids.length + "</span><span class='sp'></span>" +
      '<span class="tagpill" style="background:' + DCOLOR[c.d] + '1f;color:' + DCOLOR[c.d] + '">D' + d.n + " " + esc(c.g) + "</span></div></div>" +

    '<div class="fcard" data-flip><span class="side">' + (CR.show ? "ANSWER" : "QUESTION") + "</span>" +
      '<div class="front' + (isEn ? " en" : "") + '">' + esc(c.f) + "</div>" +
      (CR.show ? '<div class="back">' + esc(c.b) + "</div>"
               : '<div class="hint">' + (r && r.n ? "前回から " + (TODAY() - (r.due - r.ivl)) + " 日 ・ 間隔 " + r.ivl + " 日" : "初めてのカード") + " — タップで答えを表示</div>") +
    "</div>" +

    (CR.show
      ? '<div class="grades">' +
        '<button class="g0" data-grade="0"><b>もう一度</b><span>今日</span></button>' +
        '<button class="g1" data-grade="1"><b>難しい</b><span>' + previewIvl(c, 1) + "</span></button>" +
        '<button class="g2" data-grade="2"><b>普通</b><span>' + previewIvl(c, 2) + "</span></button>" +
        '<button class="g3" data-grade="3"><b>簡単</b><span>' + previewIvl(c, 3) + "</span></button></div>"
      : '<button class="btn" data-flip>答えを見る</button>') +
    '<div style="height:20px"></div>';

  return { bar: barTitle(CR.label, "単語カード", false, '<button class="iconbtn wide" data-quitcard>終了</button>'),
           html: html, hideTabs: true, full: true };
};
function previewIvl(c, g) {
  var r = S.c[c.i] || { n: 0, box: 0, ease: 2.5, ivl: 0 }, box = Math.min(8, r.box + 1), ivl;
  if (box <= 1) ivl = (g === 1 ? 1 : g === 2 ? 2 : 4);
  else if (box === 2) ivl = (g === 1 ? 3 : g === 2 ? 6 : 10);
  else ivl = Math.max(1, Math.round(r.ivl * r.ease * (g === 1 ? 0.65 : g === 2 ? 1 : 1.35)));
  return ivl >= 30 ? (ivl / 30).toFixed(ivl >= 60 ? 0 : 1) + "か月" : ivl + "日";
}

/* --------------------------------------------------------- recall (記述) */
var RC = null;
VIEWS.recall = function () {
  if (!RC) RC = { ids: shuffle(WRITTEN.map(function (w) { return w.i; })), idx: 0, show: false };
  if (RC.idx >= RC.ids.length) {
    RC = null;
    return { bar: barTitle("完了"), html: '<div class="empty"><div class="big">✓</div><b>ひと通り確認しました</b><span class="tiny">自分の言葉で説明できたものは定着しています</span></div>' +
      '<div class="stack"><button class="btn" data-go="cards">暗記メニューへ</button></div>' };
  }
  var w = null, id = RC.ids[RC.idx];
  WRITTEN.forEach(function (x) { if (x.i === id) w = x; });
  var d = DOM_BY_ID[w.d];
  var html =
    '<div class="qprog"><div class="qbar"><i style="width:' + (RC.idx / RC.ids.length * 100) + '%"></i></div>' +
      '<div class="qmeta"><span class="num">' + (RC.idx + 1) + " / " + RC.ids.length + '</span><span class="sp"></span>' +
      '<span class="tagpill" style="background:' + DCOLOR[w.d] + '1f;color:' + DCOLOR[w.d] + '">D' + d.n + "</span></div></div>" +
    '<div class="card"><div style="font-size:17px;line-height:1.85;font-weight:500">' + esc(w.q) + "</div></div>" +
    '<p class="tiny dimt center">まず声に出して答えてから開いてください</p>' +
    (RC.show ? '<div class="expl"><span class="lab">模範解答</span>' + md(w.m) + "</div>" : "") +
    '<div class="qfoot">' +
      (RC.show ? '<button class="btn" data-recall="next">次へ →</button>'
               : '<button class="btn ghost" data-recall="show">模範解答を見る</button>') +
    "</div>";
  return { bar: barTitle("記述で確認", "アクティブリコール", false, '<button class="iconbtn wide" data-quitrecall>終了</button>'),
           html: html, hideTabs: true, full: true };
};
function md(s) {
  return esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>");
}

/* ==================================================== VIEW: reading === */
VIEWS.read = function () {
  var readCount = Object.keys(S.read).length;
  var totalSecs = 0;
  DOMAINS.forEach(function (d) { totalSecs += d.secs.length; });
  var html =
    '<div class="stack">' +
      '<button class="btn ghost" data-go="cheat">まとめ・早見表（' + CHEATS.length + "枚）</button>" +
      '<button class="btn ghost" data-go="search">用語を検索する</button>' +
    "</div>" +
    '<h2 class="sec">教科書</h2>' +
    '<div class="tiny dimt" style="margin:-4px 2px 8px">' + readCount + " / " + totalSecs + " 節を既読</div>" +
    '<div class="list">' + DOMAINS.map(function (d) {
      var rd = d.secs.filter(function (s) { return S.read[d.id + "/" + s.id]; }).length;
      return '<button class="li" data-go="readdom" data-d="' + d.id + '">' +
        '<span class="mk" style="background:' + DCOLOR[d.id] + '22;color:' + DCOLOR[d.id] + '">' + d.n + "</span>" +
        '<span class="lead"><span class="t">' + esc(d.t) + '</span><span class="s">' + esc(d.en) + " ・ 出題比率 " + d.w + "%</span>" +
        '<span class="bar" style="margin-top:7px"><i style="width:' + (rd / d.secs.length * 100) + "%;background:" + DCOLOR[d.id] + '"></i></span></span>' +
        '<span class="arw">›</span></button>';
    }).join("") + "</div>";
  return { bar: barTitle("教科書", "全8ドメイン", false, '<button class="iconbtn" data-go="search" aria-label="検索">' + ICON.search + "</button>"), html: html };
};

VIEWS.readdom = function (p) {
  var d = DOM_BY_ID[p.d];
  var html =
    '<div class="card"><span class="tiny dimt">DOMAIN ' + d.n + " ・ 出題比率 " + d.w + "%</span>" +
      '<div class="disp" style="font-size:20px;margin:5px 0 10px">' + esc(d.t) + "</div>" +
      '<div class="tiny mut" style="line-height:1.85">' + esc(d.lead) + "</div></div>" +
    '<div class="list">' + d.secs.map(function (s, i) {
      var done = !!S.read[d.id + "/" + s.id];
      var sm = sectionMastery(d.id, s.id);
      return '<button class="li" data-go="readsec" data-d="' + d.id + '" data-s="' + s.id + '">' +
        '<span class="mk" style="' + (done ? "background:var(--matsu-w);color:var(--matsu)" : "") + '">' + (done ? "✓" : s.n) + "</span>" +
        '<span class="lead"><span class="t">' + esc(s.t) + "</span>" +
        (sm.n ? '<span class="s">問題 ' + sm.n + " 問 ・ 到達度 " + pct(sm.m) + "%</span>" : "") + "</span>" +
        '<span class="arw">›</span></button>';
    }).join("") + "</div>";
  return { bar: barTitle("Domain " + d.n, d.t, true), html: html };
};

VIEWS.readsec = function (p) {
  var d = DOM_BY_ID[p.d], idx = -1;
  d.secs.forEach(function (s, i) { if (s.id === p.s) idx = i; });
  if (idx < 0) idx = 0;
  var s = d.secs[idx], key = d.id + "/" + s.id;
  if (!S.read[key]) { S.read[key] = Date.now(); todayRec().sec++; save(); }
  var sm = sectionMastery(d.id, s.id);
  var prev = idx > 0 ? d.secs[idx - 1] : null, next = idx < d.secs.length - 1 ? d.secs[idx + 1] : null;

  var html =
    '<div class="doc">' + s.h + "</div>" +
    (sm.n ? '<div class="card" style="margin-top:22px"><div class="row"><div class="sp"><b>この節の問題</b>' +
      '<div class="tiny dimt" style="margin-top:3px">' + sm.seen + " / " + sm.n + " 問に着手 ・ 到達度 " + pct(sm.m) + "%</div></div></div>" +
      '<button class="btn sm" style="margin-top:12px;width:100%" data-go="quiz" data-mode="sec" data-d="' + d.id + '" data-s="' + s.id + '">' + sm.n + "問を解く</button></div>" : "") +
    '<div class="row" style="gap:8px;margin-top:18px">' +
      (prev ? '<button class="btn ghost sm" style="flex:1" data-go="readsec" data-d="' + d.id + '" data-s="' + prev.id + '">‹ ' + esc(prev.t.slice(0, 10)) + "</button>" : '<span style="flex:1"></span>') +
      (next ? '<button class="btn sm" style="flex:1" data-go="readsec" data-d="' + d.id + '" data-s="' + next.id + '">' + esc(next.t.slice(0, 10)) + " ›</button>" : '<span style="flex:1"></span>') +
    "</div>";
  return { bar: barTitle(s.t, "Domain " + d.n, true), html: html };
};

VIEWS.cheat = function () {
  var html = '<p class="tiny dimt" style="margin:14px 2px">試験直前に見返す用の凝縮版です。表と対比で覚えるものを集めています。</p>' +
    '<div class="list">' + CHEATS.map(function (c, i) {
      return '<button class="li" data-go="cheatone" data-i="' + i + '">' +
        '<span class="mk" style="background:var(--kin-w);color:var(--kin)">' + (i + 1) + "</span>" +
        '<span class="lead"><span class="t">' + esc(c.t) + '</span><span class="s">' + esc(c.sub) + "</span></span>" +
        '<span class="arw">›</span></button>';
    }).join("") + "</div>";
  return { bar: barTitle("まとめ・早見表", CHEATS.length + " 枚", true), html: html };
};
VIEWS.cheatone = function (p) {
  var i = +p.i, c = CHEATS[i];
  var prev = i > 0 ? i - 1 : null, next = i < CHEATS.length - 1 ? i + 1 : null;
  return { bar: barTitle(c.t, c.sub, true), html:
    '<div class="doc">' + c.h + "</div>" +
    '<div class="row" style="gap:8px;margin-top:20px">' +
      (prev !== null ? '<button class="btn ghost sm" style="flex:1" data-go="cheatone" data-i="' + prev + '">‹ ' + esc(CHEATS[prev].t) + "</button>" : '<span style="flex:1"></span>') +
      (next !== null ? '<button class="btn sm" style="flex:1" data-go="cheatone" data-i="' + next + '">' + esc(CHEATS[next].t) + " ›</button>" : '<span style="flex:1"></span>') +
    "</div>" };
};

/* ==================================================== VIEW: search ==== */
var SQ = "";
VIEWS.search = function () {
  var html =
    '<div class="searchbox"><span class="dimt" style="display:flex">' + ICON.search + "</span>" +
    '<input id="sq" type="search" placeholder="用語・略語・キーワード" value="' + esc(SQ) + '" autocomplete="off" autocapitalize="off" spellcheck="false"></div>' +
    '<div id="sres"></div>';
  return { bar: barTitle("検索", "問題・カード・教科書から", true), html: html, after: function () {
    var inp = $("#sq");
    inp.addEventListener("input", function () { SQ = inp.value; doSearch(); });
    doSearch();
    if (!SQ) setTimeout(function () { try { inp.focus(); } catch (e) {} }, 120);
  } };
};
function hl(text, q) {
  if (!q) return esc(text);
  var re = new RegExp("(" + q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "gi");
  return esc(text).replace(re, "<mark>$1</mark>");
}
function doSearch() {
  var q = SQ.trim(), box = $("#sres");
  if (!box) return;
  if (q.length < 1) {
    box.innerHTML = '<div class="empty"><div class="big">⌕</div><b>キーワードを入力</b><span class="tiny">例： Kerberos、RTO、BLP、職務分掌</span></div>';
    return;
  }
  var lq = q.toLowerCase(), out = [];
  CARDS.forEach(function (c) {
    if ((c.f + " " + c.b).toLowerCase().indexOf(lq) >= 0) out.push({ k: "card", c: c });
  });
  QS.forEach(function (x) {
    if ((x.q + " " + x.e + " " + x.o.join(" ")).toLowerCase().indexOf(lq) >= 0) out.push({ k: "q", q: x });
  });
  DOMAINS.forEach(function (d) {
    d.secs.forEach(function (s) {
      var plain = s.h.replace(/<[^>]+>/g, " ");
      if ((s.t + " " + plain).toLowerCase().indexOf(lq) >= 0) out.push({ k: "sec", d: d, s: s, plain: plain });
    });
  });
  if (!out.length) {
    box.innerHTML = '<div class="empty"><div class="big">—</div><b>見つかりませんでした</b><span class="tiny">別の言い方や英語の略語で試してください</span></div>';
    return;
  }
  var cards = out.filter(function (x) { return x.k === "card"; }).slice(0, 12);
  var qs = out.filter(function (x) { return x.k === "q"; }).slice(0, 12);
  var secs = out.filter(function (x) { return x.k === "sec"; }).slice(0, 10);
  var h = "";
  if (secs.length) h += '<h2 class="sec">教科書 ' + secs.length + '</h2><div class="list">' + secs.map(function (x) {
    var i = x.plain.toLowerCase().indexOf(lq), snip = x.plain.slice(Math.max(0, i - 30), i + 70).trim();
    return '<button class="li" data-go="readsec" data-d="' + x.d.id + '" data-s="' + x.s.id + '">' +
      '<span class="mk" style="background:' + DCOLOR[x.d.id] + '22;color:' + DCOLOR[x.d.id] + '">' + x.d.n + "</span>" +
      '<span class="lead"><span class="t">' + hl(x.s.t, q) + '</span><span class="s">…' + hl(snip, q) + "…</span></span></button>";
  }).join("") + "</div>";
  if (cards.length) h += '<h2 class="sec">単語カード ' + cards.length + '</h2><div class="list">' + cards.map(function (x) {
    return '<div class="li"><span class="mk" style="background:' + DCOLOR[x.c.d] + '22;color:' + DCOLOR[x.c.d] + '">' + DOM_BY_ID[x.c.d].n + "</span>" +
      '<span class="lead"><span class="t">' + hl(x.c.f, q) + '</span><span class="s">' + hl(x.c.b, q) + "</span></span></div>";
  }).join("") + "</div>";
  if (qs.length) h += '<h2 class="sec">問題 ' + qs.length + '</h2>' + qs.map(function (x) {
    return '<div class="card tight"><div style="font-size:14.5px;line-height:1.7;font-weight:600">' + hl(x.q.q, q) + "</div>" +
      '<div class="tiny" style="margin-top:8px;color:var(--matsu)">正答： ' + hl(x.q.o[x.q.a], q) + "</div>" +
      '<div class="tiny mut" style="margin-top:7px;line-height:1.75">' + x.q.e + "</div>" +
      '<button class="btn sm quiet" style="margin-top:10px" data-go="readsec" data-d="' + x.q.d + '" data-s="' + x.q.s + '">📖 ' + esc(SEC_TITLE[x.q.d + "/" + x.q.s] || "") + "</button></div>";
  }).join("");
  box.innerHTML = h;
}

/* ==================================================== VIEW: stats ===== */
VIEWS.stats = function () {
  var att = 0, cor = 0, seen = 0, mastered = 0, ms = 0;
  QS.forEach(function (q) { var r = S.q[q.i]; if (r && r.n) { att += r.n; cor += r.c; seen++; ms += r.ms || 0;
    if (r.box >= MASTER_BOX) mastered++; } });
  var sess = S.sess.slice(-14);
  var weak = weakSections().slice(0, 8);
  var rd = readiness();
  var days = Object.keys(S.hist).sort();
  var heat = "";
  var start = TODAY() - 55;
  for (var i = 0; i < 56; i++) {
    var k = fromDay(start + i), h = S.hist[k], n = h ? h.q + h.card : 0;
    var lv = n === 0 ? "" : n < 10 ? "l1" : n < 25 ? "l2" : n < 50 ? "l3" : "l4";
    heat += '<i class="' + lv + '" title="' + k + " " + n + '"></i>';
  }

  var html =
    '<div class="card"><div class="row"><div class="sp"><b>合格到達度</b>' +
      '<div class="tiny dimt" style="margin-top:3px">各ドメインの到達度を出題比率で加重</div></div>' +
      '<div class="num" style="font-size:30px;font-weight:700;color:' + (rd < .4 ? "var(--shu)" : rd < .7 ? "var(--kin)" : "var(--matsu)") + '">' + pct(rd) + "</div></div>" +
      '<div class="bar" style="margin-top:12px;height:9px"><i style="width:' + pct(rd) + "%;background:" + (rd < .4 ? "var(--shu)" : rd < .7 ? "var(--kin)" : "var(--matsu)") + '"></i></div></div>' +

    '<div class="kpis">' +
      '<div class="kpi"><span class="n">' + att + '</span><span class="l">のべ解答数</span></div>' +
      '<div class="kpi"><span class="n">' + (att ? pct(cor / att) : 0) + '<span style="font-size:13px;color:var(--dim)">%</span></span><span class="l">通算正答率</span></div>' +
      '<div class="kpi"><span class="n">' + mastered + '</span><span class="l">定着した問題</span></div>' +
    "</div>" +

    '<h2 class="sec">ドメイン別の到達度</h2><div class="card">' +
      DOMAINS.map(function (d) {
        var m = domainMastery(d.id);
        return '<div class="dbar"><span class="n" style="color:' + DCOLOR[d.id] + '">' + d.n + "</span>" +
          '<span class="nm">' + esc(DSHORT[d.id]) + "</span>" +
          '<span class="bar"><i style="width:' + pct(m.m) + "%;background:" + DCOLOR[d.id] + '"></i></span>' +
          '<span class="pc">' + pct(m.m) + "</span><span class='wt'>" + d.w + "%</span></div>";
      }).join("") + "</div>" +

    '<h2 class="sec">学習の記録（8週間）</h2><div class="card tight"><div class="heat">' + heat + "</div>" +
      '<div class="tiny dimt" style="margin-top:10px">1日あたりの問題＋カード枚数</div></div>' +

    (weak.length ? '<h2 class="sec">優先して埋めたい弱点</h2><div class="list">' + weak.map(function (w) {
      return '<button class="li" data-go="quiz" data-mode="sec" data-d="' + w.d + '" data-s="' + w.s + '">' +
        '<span class="mk" style="background:var(--shu-w);color:var(--shu)">' + w.dn + "</span>" +
        '<span class="lead"><span class="t">' + esc(w.t) + '</span><span class="s">到達度 ' + pct(w.m) + "% ・ " + w.n + " 問</span></span>" +
        '<span class="arw">›</span></button>';
    }).join("") + "</div>" : "") +

    (sess.length ? '<h2 class="sec">直近のセッション</h2><div class="list">' + sess.slice().reverse().map(function (x) {
      var dt = new Date(x.ts), p = x.n ? x.c / x.n : 0;
      return '<div class="li"><span class="lead"><span class="t">' + esc(x.mode) + '</span>' +
        '<span class="s">' + (dt.getMonth() + 1) + "/" + dt.getDate() + " " + pad(dt.getHours()) + ":" + pad(dt.getMinutes()) + " ・ " + hhmm(x.secs) + "</span></span>" +
        '<span class="tagpill ' + (p >= .8 ? "m" : p >= .6 ? "k" : "s") + '">' + x.c + "/" + x.n + "</span></div>";
    }).join("") + "</div>" : "") +

    '<div class="stack" style="margin-top:18px"><button class="btn ghost" data-go="settings">設定とバックアップ</button></div>';

  return { bar: barTitle("記録", "学習の進み具合"), html: html };
};

/* ==================================================== VIEW: settings == */
VIEWS.settings = function () {
  var st = S.set;
  var html =
    '<h2 class="sec">試験</h2><div class="list">' +
      '<div class="field"><span class="lb"><b>受験予定日</b><span>今日の画面にカウントダウンを表示します</span></span>' +
      '<input type="date" id="examDate" value="' + esc(st.examDate) + '"></div>' +
      '<div class="field"><span class="lb"><b>1日の目標問題数</b><span>連続記録の判定に使います</span></span>' +
      '<input type="number" id="goal" min="5" max="200" step="5" value="' + (st.goal || 20) + '"></div>' +
    "</div>" +

    '<h2 class="sec">表示</h2><div class="list">' +
      '<div class="field"><span class="lb"><b>テーマ</b><span>夜は暗色、日中は紙色が読みやすいです</span></span>' +
      '<div class="seg"><button data-theme="dark" class="' + (st.theme === "dark" ? "on" : "") + '">暗</button>' +
      '<button data-theme="light" class="' + (st.theme === "light" ? "on" : "") + '">紙</button>' +
      '<button data-theme="auto" class="' + (st.theme === "auto" ? "on" : "") + '">自動</button></div></div>' +
    "</div>" +

    '<h2 class="sec">進捗データ</h2>' +
    '<div class="card tight"><p class="tiny mut" style="margin:0 0 12px;line-height:1.8">' +
      "進捗はこの端末の中だけに保存されます。Safari は長期間使わないサイトのデータを自動削除することがあるので、" +
      "節目ごとにバックアップを書き出しておくと安全です。</p>" +
      '<div class="stack">' +
      '<button class="btn ghost" data-export>バックアップを書き出す</button>' +
      '<button class="btn ghost" data-import>バックアップを読み込む</button>' +
      "</div></div>" +
    '<input type="file" id="fimp" accept="application/json,.json" style="display:none">' +

    '<div class="card tight"><div class="stack">' +
      '<button class="btn danger" data-reset>すべての学習記録を消す</button>' +
    "</div></div>" +

    '<h2 class="sec">この教材について</h2>' +
    '<div class="card tight"><div class="tiny mut" style="line-height:1.9">' +
      "収録： 問題 " + QS.length + " 問 ・ 単語カード " + CARDS.length + " 枚 ・ 記述 " + WRITTEN.length + " 問 ・ 早見表 " + CHEATS.length + " 枚 ・ 教科書 8 ドメイン<br>" +
      "出題比率は ISC2 CISSP Exam Outline（2024年4月15日版）に準拠しています。<br>" +
      "保存方式： " + (hasLS ? "この端末のブラウザ内（localStorage）" : hasWS ? "アプリ内ストレージ" : "メモリのみ（再読込で消えます）") + "<br>" +
      "教材バージョン： " + esc(DATA.build || "—") +
    "</div></div>" +

    '<div class="card tight"><b style="font-size:14px">ホーム画面に追加すると使いやすくなります</b>' +
    '<div class="tiny mut" style="margin-top:8px;line-height:1.9">Safari で共有ボタン → 「ホーム画面に追加」。' +
    "全画面で起動し、通信がなくても動きます。</div></div>";

  return { bar: barTitle("設定", "", true), html: html, after: function () {
    var ed = $("#examDate"); if (ed) ed.addEventListener("change", function () { S.set.examDate = ed.value; save(); toast("受験日を設定しました"); });
    var g = $("#goal"); if (g) g.addEventListener("change", function () { S.set.goal = clamp(+g.value || 20, 5, 200); save(); });
    var f = $("#fimp"); if (f) f.addEventListener("change", function () {
      var file = f.files && f.files[0]; if (!file) return;
      var fr = new FileReader();
      fr.onload = function () {
        try {
          var o = JSON.parse(fr.result);
          if (!o || !o.q) throw 0;
          S = migrate(o); saveNow(); applyTheme(); toast("バックアップを読み込みました"); go("stats", {}, true);
        } catch (e) { toast("ファイルを読み込めませんでした"); }
      };
      fr.readAsText(file);
    });
  } };
};

function exportBackup() {
  var blob = new Blob([JSON.stringify(S)], { type: "application/json" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url; a.download = "cissp-progress-" + today() + ".json";
  document.body.appendChild(a); a.click();
  setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 400);
  toast("ファイルアプリに保存できます");
}

/* ---------------------------------------------------------- theme ---- */
function applyTheme() {
  var t = S.set.theme;
  if (t === "auto") t = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", t);
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", t === "light" ? "#F1ECE2" : "#0D131B");
}

/* --------------------------------------------------------- events ---- */
function closestData(el, attr) {
  while (el && el !== document.body) {
    if (el.hasAttribute && el.hasAttribute(attr)) return el;
    el = el.parentNode;
  }
  return null;
}
document.addEventListener("click", function (ev) {
  var t = ev.target, el;

  if ((el = closestData(t, "data-mok"))) { var cb = modalCB; closeModal(); if (cb) cb(); return; }
  if ((el = closestData(t, "data-mno"))) { closeModal(); return; }
  if (t.id === "modal") { closeModal(); return; }

  if ((el = closestData(t, "data-back"))) { back(); return; }
  if ((el = closestData(t, "data-tab"))) { tabGo(el.dataset.tab); return; }

  if ((el = closestData(t, "data-plan"))) {
    var k = el.dataset.plan;
    if (k === "card") go("cardrun", { mode: "mix" });
    else go("quiz", { mode: k });
    return;
  }
  if ((el = closestData(t, "data-mock"))) {
    var n = +el.dataset.mock;
    if (S.mock) { confirmBox("模擬試験を新しく始めますか", "中断中の模擬試験は破棄されます。", "新しく始める", function () { S.mock = null; go("quiz", { mode: "mock", n: n }); }, true); return; }
    confirmBox(n + "問の模擬試験を始めます", "制限時間は " + Math.round(n * 72 / 60) + " 分。途中で正誤は表示されず、最後にまとめて採点します。中断しても続きから再開できます。", "始める", function () { go("quiz", { mode: "mock", n: n }); });
    return;
  }
  if ((el = closestData(t, "data-resume"))) { go("quiz", { mode: "mock", resume: 1 }); return; }
  if ((el = closestData(t, "data-dropmock"))) {
    confirmBox("模擬試験を破棄しますか", "解答した内容は記録されません。", "破棄する", function () { S.mock = null; save(); render(); }, true); return;
  }

  if ((el = closestData(t, "data-go"))) {
    var d = el.dataset;
    var p = {};
    if (d.d) p.d = d.d; if (d.s) p.s = d.s; if (d.mode) p.mode = d.mode; if (d.i) p.i = d.i;
    if (d.go === "quiz") { Q = null; }
    if (d.go === "cardrun") { CR = null; }
    if (d.go === "home" || d.go === "drill" || d.go === "cards" || d.go === "read" || d.go === "stats") {
      if (!d.mode && !d.d) { tabGo(d.go); return; }
    }
    go(d.go, p);
    return;
  }

  /* quiz */
  if ((el = closestData(t, "data-opt"))) {
    if (!Q || Q.locked) return;
    Q.picked = +el.dataset.opt; haptic(); render(); return;
  }
  if (closestData(t, "data-check")) { checkAnswer(); return; }
  if (closestData(t, "data-next")) { nextQuestion(); return; }
  if (closestData(t, "data-flag")) {
    if (!Q) return;
    var id = Q.ids[Q.idx], i = S.flagQ.indexOf(id);
    if (i >= 0) { S.flagQ.splice(i, 1); toast("フラグを外しました"); }
    else { S.flagQ.push(id); toast("フラグを付けました"); }
    save(); render(); return;
  }
  if (closestData(t, "data-quit")) {
    if (!Q) { back(); return; }
    if (Q.mock) {
      confirmBox("模擬試験を中断しますか", "続きから再開できます。", "中断する", function () {
        S.mock = Q; saveNow(); stopTimer(); Q = null; tabGo("drill");
      });
    } else if (Q.idx > 0 || Q.locked) {
      confirmBox("演習を終了しますか", "ここまでの解答は記録されています。", "終了する", function () {
        stopTimer(); if (Q) finishQuiz(false);
      });
    } else { stopTimer(); Q = null; back(); }
    return;
  }

  /* cards */
  if (closestData(t, "data-flip")) { if (CR) { CR.show = true; render(); } return; }
  if ((el = closestData(t, "data-grade"))) {
    if (!CR) return;
    var g = +el.dataset.grade, c = C_BY_ID[CR.ids[CR.idx]];
    gradeCard(c, g); CR.done++;
    if (g === 0) CR.again.push(c.i);
    CR.idx++; CR.show = false; save(); haptic(); render(); window.scrollTo(0, 0);
    return;
  }
  if (closestData(t, "data-quitcard")) { CR = null; saveNow(); tabGo("cards"); return; }

  /* recall */
  if ((el = closestData(t, "data-recall"))) {
    if (!RC) return;
    if (el.dataset.recall === "show") RC.show = true;
    else { RC.idx++; RC.show = false; }
    render(); window.scrollTo(0, 0); return;
  }
  if (closestData(t, "data-quitrecall")) { RC = null; tabGo("cards"); return; }

  /* settings */
  if ((el = closestData(t, "data-theme"))) { S.set.theme = el.dataset.theme; save(); applyTheme(); render(); return; }
  if (closestData(t, "data-export")) { exportBackup(); return; }
  if (closestData(t, "data-import")) { var f = $("#fimp"); if (f) f.click(); return; }
  if (closestData(t, "data-reset")) {
    confirmBox("すべての学習記録を消しますか", "解答履歴・カードの間隔・既読・設定がすべて初期化されます。この操作は取り消せません。", "すべて消す", function () {
      S = blank(); saveNow(); applyTheme(); tabGo("home"); toast("初期化しました");
    }, true);
    return;
  }

  /* links inside textbook content */
  var a = t.closest ? t.closest("a") : null;
  if (a && a.getAttribute("href")) {
    var href = a.getAttribute("href");
    if (href.charAt(0) === "#") {
      ev.preventDefault();
      var sid = href.slice(1), dd = route.p.d;
      if (dd && DOM_BY_ID[dd]) {
        var found = DOM_BY_ID[dd].secs.some(function (s) { return s.id === sid; });
        if (found) { go("readsec", { d: dd, s: sid }); return; }
      }
      var tgt = document.getElementById(sid);
      if (tgt && tgt.scrollIntoView) tgt.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }
    if (/^https?:/.test(href)) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener noreferrer"); }
  }
}, false);

if (window.matchMedia) {
  try {
    window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", function () {
      if (S && S.set.theme === "auto") applyTheme();
    });
  } catch (e) {}
}
window.addEventListener("pagehide", saveNow);
document.addEventListener("visibilitychange", function () { if (document.hidden) saveNow(); });

/* ----------------------------------------------------------- boot ---- */
loadState().then(function (st) {
  S = st;
  // Write the upgraded shape back straight away, so the conversion happens once
  // and is never re-run against already-converted data.
  if (MIGRATED) saveNow();
  applyTheme();
  var tb = $("#tabbar");
  tb.innerHTML = TABS.map(function (t) {
    return '<button data-tab="' + t.id + '"><span class="ti">' + t.ic + "</span>" + t.label + "</button>";
  }).join("");
  render();
  var b = document.getElementById("boot");
  if (b) b.parentNode.removeChild(b);
});

})();
