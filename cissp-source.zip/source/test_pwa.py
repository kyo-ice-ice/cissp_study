#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Serve the hosted build over HTTP and verify: service worker installs,
   the app still works, and it survives going offline."""
import http.server, socketserver, threading, functools, sys, os, time
from playwright.sync_api import sync_playwright

DIR = "/mnt/user-data/outputs"
PORT = 8731

Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=DIR)
class Quiet(socketserver.TCPServer):
    allow_reuse_address = True
httpd = Quiet(("127.0.0.1", PORT), Handler)
httpd.RequestHandlerClass.log_message = lambda *a, **k: None
threading.Thread(target=httpd.serve_forever, daemon=True).start()
BASE = "http://127.0.0.1:%d/index.html" % PORT

ok = True
def check(label, cond, extra=""):
    global ok
    print(("  PASS  " if cond else "  FAIL  ") + label + ("" if cond else "  " + str(extra)))
    if not cond: ok = False

with sync_playwright() as pw:
    b = pw.chromium.launch()
    ctx = b.new_context(viewport={"width": 393, "height": 852}, is_mobile=True,
                        has_touch=True, device_scale_factor=2)
    p = ctx.new_page(); errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))

    p.goto(BASE)
    p.wait_for_selector("#tabbar button", timeout=20000)
    p.wait_for_timeout(1200)
    check("アプリが起動する", p.locator(".octa").count() == 1)
    check("JSエラーなし", not errs, errs[:2])

    # manifest is a real file and parses
    man = p.evaluate("""async () => {
      const l = document.querySelector('link[rel=manifest]');
      if (!l) return {err:'no link'};
      const r = await fetch(l.href); const j = await r.json();
      return {ok:r.ok, name:j.name, display:j.display, icons:(j.icons||[]).length};
    }""")
    check("manifest が読める", man.get("ok") and man.get("display") == "standalone" and man.get("icons") == 1, man)

    # service worker
    reg = p.evaluate("""async () => {
      if (!('serviceWorker' in navigator)) return {err:'unsupported'};
      const r = await navigator.serviceWorker.ready;
      return {scope:r.scope, active: !!r.active};
    }""")
    check("Service Worker が有効", reg.get("active") is True, reg)

    # let the shell land in the cache
    p.wait_for_timeout(1500)
    cached = p.evaluate("""async () => {
      const ks = await caches.keys();
      const c = await caches.open(ks[0]);
      const rs = await c.keys();
      return {caches:ks, urls: rs.map(r => r.url.split('/').pop())};
    }""")
    check("アプリがキャッシュされた", any("index.html" in u for u in cached.get("urls", [])), cached)

    # progress survives an offline reload
    p.click("[data-go='quiz'][data-mode='quick']")
    p.wait_for_selector(".opt")
    p.locator(".opt").first.click(); p.click("[data-check]")
    p.wait_for_selector(".verdict"); p.wait_for_timeout(400)
    p.click("[data-quit]"); p.wait_for_selector("[data-mok]"); p.click("[data-mok]")
    p.wait_for_timeout(600)
    p.click("#tabbar [data-tab='stats']"); p.wait_for_selector(".kpi")
    before = p.inner_text(".kpi")

    ctx.set_offline(True)
    p.reload()
    p.wait_for_selector("#tabbar button", timeout=20000)
    p.wait_for_timeout(900)
    check("オフラインでも起動する", p.locator(".octa").count() == 1)
    p.click("#tabbar [data-tab='stats']"); p.wait_for_selector(".kpi")
    check("オフラインでも進捗が残る", p.inner_text(".kpi") == before)
    p.click("#tabbar [data-tab='read']"); p.wait_for_selector("[data-go='readdom']")
    p.locator("[data-go='readdom']").first.click(); p.wait_for_selector("[data-go='readsec']")
    p.locator("[data-go='readsec']").first.click(); p.wait_for_selector(".doc")
    check("オフラインでも教科書が読める", len(p.locator(".doc").inner_text()) > 100)
    check("オフライン中もJSエラーなし", not errs, errs[:2])
    ctx.set_offline(False)

    # the standalone single file must still work with no server at all
    p2 = ctx.new_page(); e2 = []
    p2.on("pageerror", lambda e: e2.append(str(e)))
    p2.goto("file:///mnt/user-data/outputs/CISSP.html")
    p2.wait_for_selector("#tabbar button", timeout=20000); p2.wait_for_timeout(800)
    check("単体HTMLも従来どおり動く", p2.locator(".octa").count() == 1 and not e2, e2[:2])
    check("単体HTMLはSWを登録しない",
          p2.evaluate("() => !navigator.serviceWorker || !navigator.serviceWorker.controller"))
    b.close()

httpd.shutdown()
print("\n" + ("ALL PASS" if ok else "FAILURES PRESENT"))
sys.exit(0 if ok else 1)
