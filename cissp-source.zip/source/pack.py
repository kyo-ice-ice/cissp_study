#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Merge every content source into one compact JSON payload for the app."""
import json, os, sys, re, hashlib, collections

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
D = os.path.join(HERE, "data")

import qbank_d1, qbank_d23, qbank_d45, qbank_d678, qbank_scn, qbank_fill, qbank_x1, qbank_x2
import cards_extra, cheats, written, expl_fix, options_fix

WEIGHTS = {"d1":16,"d2":10,"d3":13,"d4":13,"d5":13,"d6":12,"d7":13,"d8":10}

def norm(s):
    return re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', s or '')).lower()

# ---------- domains / reading ----------
domains = json.load(open(os.path.join(D, "domains.json"), encoding="utf-8"))
sec_titles = {}
for dom in domains:
    dom["w"] = WEIGHTS[dom["id"]]
    for s in dom["secs"]:
        sec_titles[(dom["id"], s["id"])] = s["t"]

# ---------- questions ----------
questions = []
seen = set()
def add_q(d, s, lvl, q, opts, ans, exp, src):
    key = norm(q)
    if key in seen:
        return False
    seen.add(key)
    questions.append({
        "d": d, "s": s, "l": lvl, "q": q, "o": list(opts), "a": ans, "e": exp, "src": src
    })
    return True

for r in json.load(open(os.path.join(D, "questions_base.json"), encoding="utf-8")):
    add_q(r["d"], r["s"], 1, r["q"], r["o"], r["a"], r["e"], "base")

for name, mod in [("d1",qbank_d1),("d23",qbank_d23),("d45",qbank_d45),
                  ("d678",qbank_d678),("scn",qbank_scn),("fill",qbank_fill),
                  ("x1",qbank_x1),("x2",qbank_x2)]:
    for r in mod.Q:
        add_q(r[0], r[1], r[2], r[3], r[4], r[5], r[6], name)

# replace the one-line explanations carried over from the source textbook
_fixed = 0
for _key, _text in expl_fix.FIX:
    _hit = [q for q in questions if _key in q["q"]]
    assert len(_hit) == 1, ("explanation fix matched %d questions" % len(_hit), _key)
    _hit[0]["e"] = _text
    _fixed += 1

# ---------- stable ids -------------------------------------------------------
# IDs are minted once and stored in ids.json, then reused forever. Editing a
# question's wording therefore keeps its ID — and every learner's progress on it.
import difflib

REG_PATH = os.path.join(HERE, "ids.json")
try:
    REG = json.load(open(REG_PATH, encoding="utf-8"))
except (IOError, ValueError):
    REG = {"q": {}, "c": {}, "next_q": 1, "next_c": 1}
for k in ("q", "c"):
    REG.setdefault(k, {})
REG.setdefault("next_q", 1)
REG.setdefault("next_c", 1)

def assign_ids(items, kind, text_of, scope_of, prefix):
    """Reuse an existing ID when the item is recognisable; mint a new one otherwise.

    Match order:
      1. exact (normalised) text  -> unchanged item
      2. close text within the same domain/section -> reworded item, ID kept
      3. new ID
    """
    reg = REG[kind]
    by_text = {}
    for rid, rec in reg.items():
        by_text.setdefault(rec["t"], rid)
    claimed, stats = set(), {"same": 0, "reworded": 0, "new": 0}

    pending = []
    for it in items:
        t = norm(text_of(it))
        rid = by_text.get(t)
        if rid and rid not in claimed:
            it["i"] = rid; claimed.add(rid); stats["same"] += 1
        else:
            pending.append((it, t))

    # fuzzy pass, scoped so a rewrite can never steal another section's ID
    free = [(rid, rec) for rid, rec in reg.items() if rid not in claimed]
    for it, t in pending:
        sc = scope_of(it)
        best, score = None, 0.0
        for rid, rec in free:
            if rec.get("s") != sc or rid in claimed:
                continue
            r = difflib.SequenceMatcher(None, t, rec["t"]).ratio()
            if r > score:
                best, score = rid, r
        if best and score >= 0.62:
            it["i"] = best; claimed.add(best); stats["reworded"] += 1
        else:
            n = REG["next_" + kind]; REG["next_" + kind] = n + 1
            it["i"] = "%s%04d" % (prefix, n); stats["new"] += 1
        reg[it["i"]] = {"t": t, "s": sc}

    for it in items:
        reg[it["i"]] = {"t": norm(text_of(it)), "s": scope_of(it)}
    stats["retired"] = len([r for r in reg if r not in set(i["i"] for i in items)])
    return stats

qstats = assign_ids(questions, "q", lambda x: x["q"], lambda x: x["d"] + "/" + x["s"], "q")
assert len(set(q["i"] for q in questions)) == len(questions), "question id collision"

# ---------- option-balance overrides ----------------------------------------
# Rewritten choice sets, keyed by permanent ID. Question wording is untouched, so
# IDs — and every learner's history — survive the edit.
# Two accepted forms:
#   [id, [four options], answer index]  — full replacement
#   [id, "shorter correct option"]      — trim just the answer, keep distractors
_ofix = 0
for _row in options_fix.OPT:
    _qid = _row[0]
    _hit = [q for q in questions if q.get("i") == _qid]
    assert len(_hit) == 1, ("options_fix: id not found: " + _qid)
    _q = _hit[0]
    if isinstance(_row[1], str):
        _q["o"] = list(_q["o"]); _q["o"][_q["a"]] = _row[1]
    else:
        _opts, _ans = _row[1], _row[2]
        assert len(_opts) == 4 and 0 <= _ans < 4, ("options_fix: bad shape: " + _qid)
        assert len(set(_opts)) == 4, ("options_fix: duplicate option: " + _qid)
        _q["o"] = list(_opts); _q["a"] = _ans
    assert len(set(_q["o"])) == len(_q["o"]), ("options_fix: duplicate option: " + _qid)
    _ofix += 1

# The whole point of this file: after every override the answer must not stand
# out by length. Fail the build rather than ship a question that gives itself away.
_still = []
for _row in options_fix.OPT:
    _q = [q for q in questions if q["i"] == _row[0]][0]
    _L = [len(o) for o in _q["o"]]; _a = _q["a"]
    _o = max(_L[i] for i in range(len(_L)) if i != _a)
    if _L[_a] - _o >= 6 and _L[_a] >= 1.25 * _o:
        _still.append("%s(%d vs %d)" % (_q["i"], _L[_a], _o))
assert not _still, "options_fix: 正解がまだ突出して長い -> " + ", ".join(_still)


# sanity: answer index in range, 4 options
bad = [q for q in questions if len(q["o"]) < 3 or not (0 <= q["a"] < len(q["o"]))]
assert not bad, bad[:3]

# unknown sections -> map to overview
valid = set(sec_titles.keys())
fixed = 0
for q in questions:
    if (q["d"], q["s"]) not in valid:
        q["s"] = "overview"; fixed += 1

# ---------- flashcards ----------
cards = []
cseen = set()
def add_c(d, g, front, back, hint):
    k = norm(front)
    if k in cseen: return
    cseen.add(k)
    cards.append({"d": d, "g": g, "f": front, "b": back, "h": hint or ""})

for r in json.load(open(os.path.join(D, "cards_base.json"), encoding="utf-8")):
    # term / japanese / explanation  -> ask for meaning
    back = r["j"] + ("　—　" + r["x"] if r.get("x") else "")
    add_c(r["d"], r["g"], r["t"], back, r["j"])
for r in cards_extra.C:
    add_c(r[0], r[1], r[2], r[3], r[4])
cstats = assign_ids(cards, "c", lambda x: x["f"], lambda x: x["d"], "c")
assert len(set(c["i"] for c in cards)) == len(cards), "card id collision"
json.dump(REG, open(REG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=0, sort_keys=True)

# ---------- one-time migration off the old content-hash IDs ------------------
# Frozen on disk: it maps what the *first published build* used, so later content
# edits can never invalidate it. Learners who installed that build keep their data.
LEG_PATH = os.path.join(HERE, "legacy_ids.json")
try:
    LEGACY = json.load(open(LEG_PATH, encoding="utf-8"))
except (IOError, ValueError):
    LEGACY = {}
    for q in questions:
        LEGACY["q" + hashlib.md5(norm(q["q"]).encode()).hexdigest()[:8]] = q["i"]
    for c in cards:
        LEGACY["c" + hashlib.md5(norm(c["f"]).encode()).hexdigest()[:8]] = c["i"]
    json.dump(LEGACY, open(LEG_PATH, "w", encoding="utf-8"), ensure_ascii=False, sort_keys=True)

# ---------- written / active recall ----------
wr = []
for i, r in enumerate(written.W):
    wr.append({"i": "w%02d" % i, "d": r[0], "s": r[1], "q": r[2], "m": r[3]})

# ---------- cheat sheets ----------
ch = [{"i": c[0], "t": c[1], "sub": c[2], "h": c[3]} for c in cheats.CHEATS]

svgcss = open(os.path.join(D, "svg.css"), encoding="utf-8").read()

payload = {
    "build": __import__("datetime").date.today().isoformat(),
    "mig": LEGACY,
    "domains": domains,
    "questions": questions,
    "cards": cards,
    "written": wr,
    "cheats": ch,
    "svgcss": svgcss,
}

out = os.path.join(HERE, "payload.json")
json.dump(payload, open(out, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))

print("questions:", len(questions), "| by domain:", dict(sorted(collections.Counter(q["d"] for q in questions).items())))
# ---------- move Latin glosses out of the correct choice ---------------------
# "RBAC（Role-Based Access Control）" next to bare "DAC" / "MAC" gives the answer
# away by length alone. The expansion belongs in the explanation, so move it there.
_GLOSS = re.compile(r'\s*[（(]([^（()）]*)[)）]\s*$')
def _is_latin(t):
    return len(t) > 1 and sum(1 for ch in t if ord(ch) < 128) / float(len(t)) >= 0.7

_gloss_moved = 0
for _q in questions:
    _a = _q["a"]; _m = _GLOSS.search(_q["o"][_a])
    if not _m or not _is_latin(_m.group(1)):
        continue
    _bare = _GLOSS.sub("", _q["o"][_a]).strip()
    if len(_bare) < 2:
        continue
    if any(_GLOSS.search(_q["o"][_i]) for _i in range(len(_q["o"])) if _i != _a):
        continue
    _q["o"][_a] = _bare
    _full = _m.group(1).strip()
    if _full and _full.lower() not in _q["e"].lower():
        _q["e"] = _q["e"].rstrip() + "　※ " + _bare + " ＝ " + _full + "。"
    _gloss_moved += 1

# ---------- option-balance report -------------------------------------------
import statistics as _st
_long = _two = 0
for _q in questions:
    _L = [len(o) for o in _q["o"]]; _a = _q["a"]
    _mw = _st.mean([_L[i] for i in range(len(_L)) if i != _a])
    if _L[_a] == max(_L) and _L.count(max(_L)) == 1: _long += 1
    if _mw and _L[_a] >= 2.0 * _mw: _two += 1
_pct = 100.0 * _long / len(questions)
print("選択肢バランス  最長=正解 %d問 (%.0f%%, 理想25%%) / 正解が誤答の2倍以上 %d問 / 手動差替 %d問 / 英語併記を解説へ移動 %d問"
      % (_long, _pct, _two, _ofix, _gloss_moved))
if _pct > 40:
    print("  !! 長さで正解が推測できる状態です。options_fix.py で差し替えてください")

print("id registry  Q: 変更なし %d / 文言修正 %d / 新規 %d | C: 変更なし %d / 文言修正 %d / 新規 %d"
      % (qstats["same"], qstats["reworded"], qstats["new"],
         cstats["same"], cstats["reworded"], cstats["new"]))
print("levels:", dict(sorted(collections.Counter(q["l"] for q in questions).items())))
print("explanations rewritten:", _fixed)
print("cards:", len(cards), "| written:", len(wr), "| cheats:", len(ch), "| remapped sections:", fixed)
print("payload bytes:", os.path.getsize(out))
