# -*- coding: utf-8 -*-
# チートシート: (id, タイトル, サブタイトル, HTML本文)

CHEATS = [

("cs-mindset", "試験思考法", "CISSP の「正解」の選び方", """
<p class="lead">CISSP は知識を問う試験であると同時に、<strong class="k">「マネージャならどう判断するか」</strong>を問う試験です。技術的に正しい選択肢が正解とは限りません。</p>
<div class="callout tip"><span class="lab">最重要の判断順序</span>
<ol>
<li><strong>人命の安全</strong>（Safety of people）— 常に最優先。他の全てに勝る。</li>
<li><strong>方針・法令・契約</strong>に従っているか</li>
<li><strong>経営層の承認・リスクオーナーの判断</strong>を得ているか</li>
<li><strong>影響範囲の把握・文書化</strong>を先に行っているか</li>
<li>そのうえでの<strong>技術的対応</strong></li>
</ol></div>

<h3>設問のキーワードで解き方が変わる</h3>
<div class="tablewrap"><table>
<thead><tr><th>キーワード</th><th>問われていること</th><th>選び方</th></tr></thead>
<tbody>
<tr><td>FIRST / 最初に</td><td>順序</td><td>「理解・評価・確認」が「実行」より先。封じ込めの前に隔離、実装の前に分析。</td></tr>
<tr><td>BEST / MOST effective</td><td>根本性</td><td>症状ではなく原因を絶つ選択肢。恒久対策 &gt; 暫定対策。</td></tr>
<tr><td>PRIMARY purpose</td><td>本来の目的</td><td>副次的効果ではなく主目的。例：職務分掌の主目的は「不正の防止」。</td></tr>
<tr><td>MOST important</td><td>前提条件</td><td>それが無いと他が成立しないもの。多くは「経営層の支持」「資産の把握」。</td></tr>
<tr><td>LEAST likely</td><td>消去法</td><td>設問が否定形。読み違いが最頻出のミス。</td></tr>
</tbody></table></div>

<h3>迷ったら思い出す原則</h3>
<ul>
<li><strong class="k">責任は委譲できるが、説明責任（accountability）は委譲できない。</strong></li>
<li>リスクを<strong class="k">受容する権限は経営層</strong>にある。セキュリティ部門は情報提供と提言まで。</li>
<li>セキュリティは<strong class="k">事業を可能にする</strong>ためにある。業務を止める統制は失敗した統制。</li>
<li>「禁止」より<strong class="k">「安全な代替手段の提供」</strong>。禁止はシャドー IT を生む。</li>
<li>技術製品の導入は、たいてい<strong class="k">最後の選択肢</strong>。まずポリシー・プロセス・人。</li>
<li>証拠は<strong class="k">保全してから</strong>調べる。電源を切る前にメモリを考える。</li>
</ul>
<div class="callout exam"><span class="lab">CAT 形式の攻略</span>
現行の CISSP は <strong>CAT（適応型）で 100〜150 問／3時間</strong>、合格は 1000 点満点中 <strong>700 点</strong>。
一度回答すると<strong>戻れません</strong>。1 問あたり平均 1 分強のペースで、迷ったら消去法で決めて進むこと。
「問題が難しく感じる」のは、正解し続けて難易度が上がっている良い兆候です。
</div>
"""),

("cs-risk", "リスクと統制", "計算式・統制タイプ・対応戦略", """
<h3>定量的リスク分析の式</h3>
<div class="card">
<p style="font-size:1.05rem"><strong class="k">EF</strong>（暴露係数）＝ 損失する資産価値の割合<br>
<strong class="k">SLE</strong>（単一損失予測）＝ <strong>AV × EF</strong><br>
<strong class="k">ARO</strong>（年間発生率）＝ 1年あたりの発生回数<br>
<strong class="k">ALE</strong>（年間損失予測）＝ <strong>SLE × ARO</strong></p>
<p><strong>対策の価値</strong> ＝ ALE(対策前) − ALE(対策後) − 対策の年間コスト<br>
→ この値が<strong class="k">正なら投資は合理的</strong>。</p>
</div>
<div class="callout tip"><span class="lab">例題の解き方</span>
資産500万円、洪水で40%損失、25年に1回 → SLE = 500万×0.4 = 200万。ARO = 1/25 = 0.04。ALE = 200万×0.04 = <strong>8万円/年</strong>。
年間8万円を超える対策は、このリスク単体では正当化しにくい。</div>

<h3>統制の分類（2軸で覚える）</h3>
<div class="tablewrap"><table>
<thead><tr><th>機能 ＼ 種類</th><th>管理的（Administrative）</th><th>技術的（Technical）</th><th>物理的（Physical）</th></tr></thead>
<tbody>
<tr><td><strong>抑止 Deterrent</strong></td><td>懲戒規定</td><td>ログイン警告バナー</td><td>警告看板・照明</td></tr>
<tr><td><strong>予防 Preventive</strong></td><td>方針・職務分掌・採用審査</td><td>FW・暗号化・アクセス制御</td><td>施錠・フェンス・警備員</td></tr>
<tr><td><strong>検知 Detective</strong></td><td>監査・レビュー</td><td>IDS・SIEM・ログ監視</td><td>監視カメラ・センサ</td></tr>
<tr><td><strong>是正 Corrective</strong></td><td>インシデント手順</td><td>パッチ・隔離・AV駆除</td><td>消火設備</td></tr>
<tr><td><strong>復旧 Recovery</strong></td><td>BCP/DRP</td><td>バックアップ復元</td><td>代替施設</td></tr>
<tr><td><strong>補償 Compensating</strong></td><td colspan="3">本来の統制が実装できない場合の代替（例：職務分掌の代わりに詳細ログ＋上長レビュー）</td></tr>
<tr><td><strong>指示 Directive</strong></td><td colspan="3">手順書・標識・利用規定など「こうせよ」と示すもの</td></tr>
</tbody></table></div>

<h3>リスク対応の4つ（＋1）</h3>
<div class="tablewrap"><table>
<thead><tr><th>戦略</th><th>内容</th><th>例</th></tr></thead>
<tbody>
<tr><td><strong>Avoid</strong>（回避）</td><td>リスクのある活動をやめる</td><td>該当事業からの撤退</td></tr>
<tr><td><strong>Mitigate</strong>（低減）</td><td>統制で発生確率・影響を下げる</td><td>暗号化、MFA</td></tr>
<tr><td><strong>Transfer</strong>（移転／共有）</td><td>他者に負担させる（説明責任は残る）</td><td>保険、アウトソース</td></tr>
<tr><td><strong>Accept</strong>（受容）</td><td>対策せず受け入れる（要：経営層の承認と記録）</td><td>低リスクの放置</td></tr>
<tr><td><strong>Reject</strong>（拒否）</td><td>リスクの存在を認めない → <strong class="k">不適切</strong>。試験では常に誤答</td><td>—</td></tr>
</tbody></table></div>

<h3>覚える用語</h3>
<ul>
<li><strong>Total Risk</strong>＝脅威×脆弱性×資産価値／<strong>Residual Risk</strong>＝Total Risk − 統制の効果</li>
<li><strong>Risk Appetite</strong>（どれだけ取りにいくか）／<strong>Risk Tolerance</strong>（どこまで許容できるか）</li>
<li><strong>KRI</strong>＝リスク増大の先行指標／<strong>KPI</strong>＝目標達成度の成果指標</li>
<li><strong>NIST RMF</strong>：Prepare → Categorize → Select → Implement → Assess → Authorize → Monitor</li>
</ul>
"""),

("cs-bcp", "BCP / DR", "時間指標・サイト種別・テスト強度", """
<h3>時間指標（最頻出）</h3>
<div class="tablewrap"><table>
<thead><tr><th>用語</th><th>意味</th><th>関係</th></tr></thead>
<tbody>
<tr><td><strong class="k">MTD / MTO</strong></td><td>最大許容停止時間。これを超えると事業が回復不能</td><td>事業側が決める上限</td></tr>
<tr><td><strong class="k">RTO</strong></td><td>復旧目標時間（どれだけ早く戻すか）</td><td><strong>RTO ≦ MTD</strong> が絶対条件</td></tr>
<tr><td><strong class="k">RPO</strong></td><td>復旧目標時点＝許容できるデータ損失量</td><td>バックアップ間隔を規定</td></tr>
<tr><td><strong>WRT</strong></td><td>復旧後、業務再開に必要な検証時間</td><td><strong>RTO + WRT ≦ MTD</strong></td></tr>
<tr><td><strong>MTBF</strong></td><td>平均故障間隔（修理可能な機器）</td rowspan="1"><td rowspan="2">可用性 = MTBF ÷ (MTBF + MTTR)</td></tr>
<tr><td><strong>MTTR</strong></td><td>平均修復時間</td></tr>
<tr><td><strong>MTTF</strong></td><td>平均故障寿命（交換前提の部品）</td><td>—</td></tr>
</tbody></table></div>
<div class="callout exam"><span class="lab">頻出の引っかけ</span>
RTO を MTD より長く設定した計画は<strong>成立しない</strong>。「RPO を短くしたい」＝バックアップ／レプリケーションの間隔を短くする、という因果も押さえる。</div>

<h3>可用性の「ナイン」換算</h3>
<div class="tablewrap"><table>
<thead><tr><th>可用性</th><th>年間停止許容</th><th>月間</th></tr></thead>
<tbody>
<tr><td>99%</td><td>約 3.65 日</td><td>約 7.2 時間</td></tr>
<tr><td>99.9%（スリーナイン）</td><td>約 8.76 時間</td><td>約 43.8 分</td></tr>
<tr><td>99.99%（フォーナイン）</td><td>約 52.6 分</td><td>約 4.4 分</td></tr>
<tr><td>99.999%（ファイブナイン）</td><td>約 5.26 分</td><td>約 26 秒</td></tr>
</tbody></table></div>

<h3>復旧サイトの種類</h3>
<div class="tablewrap"><table>
<thead><tr><th>種別</th><th>装備</th><th>切替時間</th><th>コスト</th></tr></thead>
<tbody>
<tr><td>Cold</td><td>建屋・電源・空調のみ</td><td>数週間</td><td>最安</td></tr>
<tr><td>Warm</td><td>機器・回線あり、データは非最新</td><td>数時間〜数日</td><td>中</td></tr>
<tr><td>Hot</td><td>機器・回線・最新データ完備</td><td>数分〜数時間</td><td>高</td></tr>
<tr><td>Mirror</td><td>本番と完全に同一構成の二重化</td><td>即時</td><td>最高</td></tr>
<tr><td>Mobile</td><td>移動可能なコンテナ型設備</td><td>可変</td><td>中</td></tr>
<tr><td>Reciprocal</td><td>他社との相互支援協定</td><td>不確実</td><td>最安だが<strong class="k">法的拘束力・容量に難</strong></td></tr>
</tbody></table></div>

<h3>DR テストの強度（弱い→強い）</h3>
<ol>
<li><strong>Read-through / Checklist</strong> — 手順書を各自が読んで確認</li>
<li><strong>Structured Walk-through / Tabletop</strong> — 関係者が集まり机上で議論</li>
<li><strong>Simulation</strong> — 想定シナリオで実際に動いてみる（本番影響なし）</li>
<li><strong>Parallel</strong> — 代替サイトで実際に処理を走らせる。<strong>本番は止めない</strong></li>
<li><strong class="k">Full Interruption</strong> — 本番を停止して切替。最も現実的だが<strong>経営層の明示的承認が必須</strong></li>
</ol>

<h3>BIA の流れ</h3>
<p>重要業務の特定 → 影響（財務・法務・評判）の評価 → MTD の決定 → RTO/RPO の設定 → 復旧優先順位付け → 復旧戦略の選定</p>
<div class="callout tip"><span class="lab">BCP 成功の最重要因子</span>技術でも予算でもなく <strong class="k">上級経営層の支持</strong>。試験でこの選択肢があれば、まず疑ってよい。</div>
"""),

("cs-crypto", "暗号", "方式・鍵長・モード・用途対応表", """
<h3>3つの柱と提供するもの</h3>
<div class="tablewrap"><table>
<thead><tr><th></th><th>機密性</th><th>完全性</th><th>真正性</th><th>否認防止</th></tr></thead>
<tbody>
<tr><td>対称鍵暗号（AES）</td><td>○</td><td>×</td><td>×</td><td>×</td></tr>
<tr><td>ハッシュ（SHA-256）</td><td>×</td><td>○</td><td>×</td><td>×</td></tr>
<tr><td>HMAC（鍵付きハッシュ）</td><td>×</td><td>○</td><td>○</td><td><strong class="k">×</strong></td></tr>
<tr><td>デジタル署名</td><td>×</td><td>○</td><td>○</td><td><strong class="k">○</strong></td></tr>
<tr><td>AEAD（AES-GCM）</td><td>○</td><td>○</td><td>○</td><td>×</td></tr>
</tbody></table></div>
<div class="callout exam"><span class="lab">最頻出</span>HMAC は鍵を双方が持つため<strong>否認防止にならない</strong>。否認防止が要件なら必ず<strong class="k">デジタル署名</strong>。</div>

<h3>主要アルゴリズム</h3>
<div class="tablewrap"><table>
<thead><tr><th>分類</th><th>アルゴリズム</th><th>鍵長／出力</th><th>備考</th></tr></thead>
<tbody>
<tr><td rowspan="4">対称</td><td>DES</td><td>56 bit</td><td>危殆化。使用禁止</td></tr>
<tr><td>3DES</td><td>実効112 bit</td><td>非推奨（Sweet32）</td></tr>
<tr><td><strong class="k">AES</strong></td><td>128/192/256（ブロック128）</td><td>ラウンド 10/12/14。現行標準</td></tr>
<tr><td>ChaCha20</td><td>256 bit</td><td>ストリーム。モバイルで高速</td></tr>
<tr><td rowspan="3">非対称</td><td>RSA</td><td>2048 以上推奨</td><td>素因数分解の困難性</td></tr>
<tr><td>ECC</td><td>256 ≒ RSA 3072</td><td>短い鍵で同等強度。省電力</td></tr>
<tr><td>Diffie-Hellman</td><td>—</td><td>鍵合意のみ。認証なし＝MITM に弱い</td></tr>
<tr><td rowspan="3">ハッシュ</td><td>MD5</td><td>128 bit</td><td>衝突あり。使用禁止</td></tr>
<tr><td>SHA-1</td><td>160 bit</td><td>衝突実証済み。署名用途禁止</td></tr>
<tr><td><strong class="k">SHA-2 / SHA-3</strong></td><td>224〜512 bit</td><td>現行推奨</td></tr>
<tr><td>パスワード</td><td>bcrypt / scrypt / <strong class="k">Argon2</strong></td><td>—</td><td>ソルト＋意図的に低速。SHA では不可</td></tr>
</tbody></table></div>

<h3>ブロック暗号のモード</h3>
<div class="tablewrap"><table>
<thead><tr><th>モード</th><th>特徴</th><th>評価</th></tr></thead>
<tbody>
<tr><td><strong>ECB</strong></td><td>ブロックごとに独立して暗号化</td><td><strong class="k">パターンが露見。使用禁止</strong></td></tr>
<tr><td>CBC</td><td>前ブロックと XOR。IV が必要</td><td>単独では改ざん検知不可</td></tr>
<tr><td>CTR</td><td>カウンタでストリーム化。並列処理可</td><td>ノンス再利用が致命的</td></tr>
<tr><td><strong class="k">GCM</strong></td><td>CTR＋認証タグ（AEAD）</td><td>現在の推奨</td></tr>
</tbody></table></div>

<h3>鍵の使い分け（署名 vs 暗号の逆転に注意）</h3>
<div class="card">
<p><strong>機密性がほしい</strong>：<span class="k">受信者の公開鍵</span>で暗号化 → 受信者の秘密鍵で復号</p>
<p><strong>署名がほしい</strong>：ハッシュを<span class="k">送信者の秘密鍵</span>で処理 → 送信者の公開鍵で検証</p>
<p><strong>両方</strong>：署名してから受信者の公開鍵で暗号化（実務ではハイブリッド：非対称でセッション鍵を配送し、本体は AES）</p>
</div>

<h3>その他の重要語</h3>
<ul>
<li><strong>PFS（Perfect Forward Secrecy）</strong>：長期鍵が漏れても過去の通信は守られる。DHE/ECDHE で実現。TLS 1.3 では必須</li>
<li><strong>対称鍵の必要数</strong>：n(n−1)/2 本 ／ 公開鍵方式なら 2n 本</li>
<li><strong>Kerckhoffs の原理</strong>：安全性はアルゴリズムの秘匿ではなく<strong class="k">鍵の秘匿</strong>に依存すべき</li>
<li><strong>Work Factor</strong>：解読に要する労力。鍵長を選ぶ根拠</li>
<li><strong>攻撃</strong>：Birthday（衝突、2^(n/2)）／Side-channel（時間・電力）／Downgrade（POODLE等）／Padding oracle／Replay</li>
</ul>
"""),

("cs-models", "セキュリティモデル", "BLP・Biba・Clark-Wilson ほか", """
<div class="tablewrap"><table>
<thead><tr><th>モデル</th><th>守るもの</th><th>ルール</th><th>覚え方</th></tr></thead>
<tbody>
<tr><td><strong class="k">Bell-LaPadula</strong></td><td>機密性</td><td>Simple：No Read <strong>Up</strong><br>★（Star）：No Write <strong>Down</strong></td><td>機密は「上を読めない・下に書けない」</td></tr>
<tr><td><strong class="k">Biba</strong></td><td>完全性</td><td>Simple：No Read <strong>Down</strong><br>★：No Write <strong>Up</strong></td><td>BLP の完全な逆。汚染を防ぐ</td></tr>
<tr><td>Clark-Wilson</td><td>完全性（商用）</td><td>Well-formed transaction／access triple（主体-プログラム-客体）／職務分掌</td><td>プログラム経由でしか触れない</td></tr>
<tr><td>Brewer-Nash<br>(Chinese Wall)</td><td>利益相反の防止</td><td>ある企業の情報にアクセスすると、競合企業の情報にアクセスできなくなる</td><td>過去の行動で権限が動的に変わる</td></tr>
<tr><td>Graham-Denning</td><td>主体・客体の生成／削除／権限移譲</td><td>8つの基本操作</td><td>権限管理の原型</td></tr>
<tr><td>Harrison-Ruzzo-Ullman</td><td>権限の変化の安全性</td><td>アクセス権の漏えい可能性は一般に決定不能</td><td>Graham-Denning の拡張</td></tr>
<tr><td>Non-interference</td><td>情報フロー</td><td>高レベルの動作が低レベルから観測できない</td><td>隠れチャネル対策</td></tr>
<tr><td>Take-Grant</td><td>権限の伝播</td><td>take / grant / create / remove の4規則</td><td>グラフで権限伝播を表現</td></tr>
<tr><td>Lattice-based</td><td>多層機密</td><td>各主体・客体に上下限のラベル。MAC の基盤</td><td>格子構造</td></tr>
</tbody></table></div>
<div class="callout tip"><span class="lab">図で覚える</span>
機密性（BLP）＝<strong>上の秘密は見せない、下に漏らさない</strong>。<br>
完全性（Biba）＝<strong>汚いものは読まない、上を汚さない</strong>。</div>

<h3>Common Criteria（ISO/IEC 15408）</h3>
<ul>
<li><strong>TOE</strong>（Target of Evaluation）：評価対象そのもの</li>
<li><strong>PP</strong>（Protection Profile）：<strong class="k">顧客側</strong>が定義する製品カテゴリの要求仕様</li>
<li><strong>ST</strong>（Security Target）：<strong class="k">ベンダ側</strong>が自製品について宣言する仕様</li>
<li><strong>EAL1〜EAL7</strong>：<strong class="k">評価の厳格さ</strong>であって「安全さ」ではない</li>
</ul>

<h3>セキュア設計原則</h3>
<ul>
<li><strong>Least Privilege</strong>（できることの最小化）／<strong>Need to Know</strong>（知ってよい情報の限定）</li>
<li><strong>Defense in Depth</strong>（多層）／<strong>Separation of Duties</strong>（職務分掌）／<strong>Dual Control</strong>（2人同時）</li>
<li><strong>Fail Safe</strong>（人命優先＝開放）／<strong>Fail Secure</strong>（機密優先＝閉鎖）— <strong class="k">避難経路は必ず Fail Safe</strong></li>
<li><strong>Open Design</strong>（Kerckhoffs）／<strong>Secure Defaults</strong>（デフォルト拒否）／<strong>Economy of Mechanism</strong>（単純さ）</li>
<li><strong>Complete Mediation</strong>（毎回検証）／<strong>Psychological Acceptability</strong>（使いやすさ）</li>
<li><strong class="k">Security through Obscurity は原則として不可</strong>（SSID 隠蔽、MAC フィルタなど）</li>
</ul>
"""),

("cs-network", "ネットワーク", "OSI・ポート・攻撃対応表", """
<h3>OSI 7層 早見表</h3>
<div class="tablewrap"><table>
<thead><tr><th>層</th><th>名称</th><th>データ単位</th><th>機器</th><th>代表プロトコル／攻撃</th></tr></thead>
<tbody>
<tr><td>7</td><td>アプリケーション</td><td>Data</td><td>プロキシ・WAF</td><td>HTTP, FTP, DNS, SMTP ／ SQLi, XSS</td></tr>
<tr><td>6</td><td>プレゼンテーション</td><td>Data</td><td>—</td><td><strong class="k">暗号化・圧縮・形式変換</strong>（JPEG, ASCII）</td></tr>
<tr><td>5</td><td>セッション</td><td>Data</td><td>—</td><td>RPC, NetBIOS ／ セッションハイジャック</td></tr>
<tr><td>4</td><td>トランスポート</td><td>Segment</td><td>—</td><td>TCP, UDP ／ SYN Flood, ポートスキャン</td></tr>
<tr><td>3</td><td>ネットワーク</td><td>Packet</td><td><strong>ルータ</strong></td><td>IP, ICMP, IPsec ／ IP スプーフィング</td></tr>
<tr><td>2</td><td>データリンク</td><td>Frame</td><td><strong>スイッチ・ブリッジ</strong></td><td>Ethernet, ARP, PPP ／ ARP スプーフィング, VLAN ホッピング</td></tr>
<tr><td>1</td><td>物理</td><td>Bit</td><td><strong>ハブ・リピータ</strong></td><td>ケーブル, 無線 ／ 盗聴, 妨害</td></tr>
</tbody></table></div>
<div class="callout tip"><span class="lab">覚え方</span>上から <strong>A</strong>ll <strong>P</strong>eople <strong>S</strong>eem <strong>T</strong>o <strong>N</strong>eed <strong>D</strong>ata <strong>P</strong>rocessing。<br>
衝突ドメインを分けるのは <strong>L2 スイッチ</strong>、ブロードキャストドメインを分けるのは <strong class="k">L3 ルータ／VLAN</strong>。</div>

<h3>ポート番号（暗記必須）</h3>
<div class="tablewrap"><table>
<thead><tr><th>Port</th><th>サービス</th><th>安全な代替</th></tr></thead>
<tbody>
<tr><td>20 / 21</td><td>FTP（データ／制御）</td><td>SFTP(22), FTPS(989/990)</td></tr>
<tr><td><strong>22</strong></td><td>SSH / SCP / SFTP</td><td>—</td></tr>
<tr><td>23</td><td>Telnet <span class="pill">平文</span></td><td>SSH(22)</td></tr>
<tr><td>25</td><td>SMTP</td><td>SMTPS(465), STARTTLS(587)</td></tr>
<tr><td>53</td><td>DNS（UDP/TCP）</td><td>DNSSEC, DoT(853), DoH(443)</td></tr>
<tr><td>67 / 68</td><td>DHCP</td><td>—</td></tr>
<tr><td>69</td><td>TFTP <span class="pill">認証なし</span></td><td>SFTP</td></tr>
<tr><td>80</td><td>HTTP <span class="pill">平文</span></td><td>HTTPS(443)</td></tr>
<tr><td>88</td><td>Kerberos</td><td>—</td></tr>
<tr><td>110 / 143</td><td>POP3 / IMAP <span class="pill">平文</span></td><td>POP3S(995) / IMAPS(993)</td></tr>
<tr><td>135/137-139/445</td><td>RPC / NetBIOS / SMB</td><td>境界で遮断</td></tr>
<tr><td>161 / 162</td><td>SNMP / SNMP Trap</td><td>SNMPv3</td></tr>
<tr><td>389</td><td>LDAP <span class="pill">平文</span></td><td>LDAPS(636)</td></tr>
<tr><td><strong>443</strong></td><td>HTTPS / TLS</td><td>—</td></tr>
<tr><td>500</td><td>ISAKMP / IKE（IPsec）</td><td>—</td></tr>
<tr><td>1433 / 1521 / 3306</td><td>SQL Server / Oracle / MySQL</td><td>外部公開しない</td></tr>
<tr><td>1812 / 1813</td><td>RADIUS</td><td>—</td></tr>
<tr><td>3389</td><td>RDP</td><td>VPN 内／踏み台経由</td></tr>
</tbody></table></div>

<h3>プロトコルの安全な置き換え</h3>
<ul>
<li>IPsec：<strong>AH</strong>＝完全性・真正性のみ（NAT 非透過）／<strong class="k">ESP</strong>＝機密性＋完全性・真正性</li>
<li>IPsec モード：<strong>トンネル</strong>＝元 IP ヘッダごと保護（拠点間）／<strong>トランスポート</strong>＝ペイロードのみ（端末間）</li>
<li>無線：WEP <span class="pill">破綻</span> → WPA(TKIP) → WPA2(CCMP/AES) → <strong class="k">WPA3(SAE)</strong></li>
<li>802.1X＝ポートベース認証（Supplicant / Authenticator / Auth Server）。NAC の中核</li>
<li>RADIUS＝UDP・パスワードのみ暗号化／<strong>TACACS+</strong>＝TCP・全体暗号化・AAA を分離</li>
</ul>

<h3>ファイアウォールの世代</h3>
<ol>
<li><strong>パケットフィルタ</strong>（ステートレス、L3/L4）</li>
<li><strong>ステートフルインスペクション</strong>（接続状態を保持）</li>
<li><strong>アプリケーションプロキシ</strong>（L7、最も安全だが低速）</li>
<li><strong>NGFW / WAF</strong>（アプリ識別・IPS 統合／HTTP 特化）</li>
</ol>
"""),

("cs-iam", "IAM", "認証要素・バイオメトリクス・アクセス制御", """
<h3>IAAA の順序</h3>
<p><strong class="k">Identification</strong>（主張）→ <strong class="k">Authentication</strong>（証明）→ <strong class="k">Authorization</strong>（権限付与）→ <strong class="k">Accounting</strong>（記録）</p>
<div class="callout exam"><span class="lab">頻出</span>共有アカウントは <strong>Accountability を破壊する</strong>ため原則禁止。特権作業も個人 ID でログインしてから昇格する。</div>

<h3>認証要素</h3>
<div class="tablewrap"><table>
<thead><tr><th>Type</th><th>分類</th><th>例</th><th>弱点</th></tr></thead>
<tbody>
<tr><td>1</td><td>知識（know）</td><td>パスワード, PIN, 秘密の質問</td><td>推測・フィッシング・使い回し</td></tr>
<tr><td>2</td><td>所持（have）</td><td>スマートカード, トークン, TOTP アプリ</td><td>紛失・盗難・SIM スワップ</td></tr>
<tr><td>3</td><td>生体（are）</td><td>指紋, 虹彩, 静脈, 顔</td><td>変更不可・誤認識・プライバシー</td></tr>
<tr><td>+</td><td>場所（somewhere you are）</td><td>GPS, IP ジオロケーション</td><td>単独では弱い</td></tr>
<tr><td>+</td><td>行動（something you do）</td><td>署名の筆跡, タイピングリズム</td><td>変動が大きい</td></tr>
</tbody></table></div>
<p><strong class="k">MFA ＝ 異なる Type の組み合わせ</strong>。パスワード＋秘密の質問は「知識×知識」で MFA ではない。</p>

<h3>バイオメトリクスの指標</h3>
<div class="tablewrap"><table>
<thead><tr><th>指標</th><th>別名</th><th>意味</th><th>影響</th></tr></thead>
<tbody>
<tr><td><strong>FRR</strong></td><td>Type <strong>I</strong> エラー</td><td>本人を誤って拒否</td><td>利便性の低下</td></tr>
<tr><td><strong>FAR</strong></td><td>Type <strong>II</strong> エラー</td><td>他人を誤って受入</td><td><strong class="k">セキュリティ上より深刻</strong></td></tr>
<tr><td><strong>CER / EER</strong></td><td>—</td><td>FRR と FAR が交差する点</td><td>低いほど高精度。<strong>製品比較の指標</strong></td></tr>
</tbody></table></div>
<p>高セキュリティ環境では感度を上げて <strong>FAR を下げる</strong>（結果として FRR は上がる）。</p>

<h3>アクセス制御モデル</h3>
<div class="tablewrap"><table>
<thead><tr><th>モデル</th><th>判断基準</th><th>特徴</th><th>典型例</th></tr></thead>
<tbody>
<tr><td><strong>DAC</strong></td><td>所有者の裁量</td><td>柔軟だが所有者が誤ると即漏えい</td><td>Windows/Unix の ACL</td></tr>
<tr><td><strong>MAC</strong></td><td>システムが強制するラベル</td><td>最も厳格。所有者も変更不可</td><td>軍事 MLS, SELinux</td></tr>
<tr><td><strong>RBAC</strong></td><td>役割</td><td>大規模で管理しやすい</td><td>企業の権限設計</td></tr>
<tr><td><strong>ABAC</strong></td><td>属性＋環境（時刻・端末・場所）</td><td>最も柔軟・動的</td><td>ゼロトラスト</td></tr>
<tr><td><strong>RuBAC</strong></td><td>ルール（if-then）</td><td>全員に一律適用</td><td>ファイアウォール ACL</td></tr>
<tr><td><strong>Risk-Adaptive</strong></td><td>リスクスコア</td><td>状況に応じて要求を変える</td><td>条件付きアクセス</td></tr>
</tbody></table></div>

<h3>SSO / フェデレーション</h3>
<ul>
<li><strong class="k">Kerberos</strong>：AS から <strong>TGT</strong> 取得 → TGS から <strong>サービスチケット</strong> 取得 → サービスへ提示。対称鍵ベース。<strong>タイムスタンプ依存（時刻同期必須、既定5分）</strong>。KDC は<strong class="k">単一障害点</strong></li>
<li><strong>SAML</strong>：XML アサーション。IdP ↔ SP。エンタープライズ Web SSO</li>
<li><strong>OAuth 2.0</strong>：<strong class="k">認可（アクセス委譲）</strong>であって認証ではない</li>
<li><strong>OIDC</strong>：OAuth 2.0 の上に ID トークン（JWT）で<strong class="k">認証</strong>を追加</li>
<li><strong>SCIM</strong>：ID の自動プロビジョニング／デプロビジョニングの標準</li>
</ul>

<h3>ライフサイクル管理</h3>
<p>プロビジョニング（人事システムを権威ソースに）→ 権限変更（異動時に<strong class="k">加算ではなく再設計</strong>）→ 定期棚卸し（<strong>権限クリープ</strong>の検出）→ デプロビジョニング（退職時<strong class="k">即時失効</strong>）</p>
<p><strong>PAM の要点</strong>：JIT 昇格・パスワード自動ローテーション・セッション録画・承認ワークフロー・常時特権（standing privilege）の削減</p>
"""),

("cs-incident", "インシデント対応", "フェーズ・証拠・フォレンジック", """
<h3>インシデント対応のフェーズ</h3>
<ol>
<li><strong class="k">Preparation</strong>（準備）— CSIRT 組成、手順、連絡網、ツール。<strong>ここの質が全体を決める</strong></li>
<li><strong>Detection &amp; Analysis</strong>（検知・分析）— トリアージ、重大度判定</li>
<li><strong class="k">Containment</strong>（封じ込め）— 拡大阻止。短期／長期の封じ込め</li>
<li><strong>Eradication</strong>（根絶）— 原因の除去、マルウェア削除、脆弱性修正</li>
<li><strong>Recovery</strong>（復旧）— 通常運用へ復帰、監視強化</li>
<li><strong>Lessons Learned</strong>（教訓）— 非難ではなく改善。統制へ反映</li>
</ol>
<div class="callout exam"><span class="lab">頻出シナリオ</span>
「感染端末を発見した。最初に何をするか」→ <strong class="k">ネットワークから隔離</strong>（封じ込め）。<br>
<strong>電源を切ってはいけない</strong>：メモリ上の揮発性証拠（暗号鍵・実行中プロセス・ネットワーク接続）を失う。</div>

<h3>証拠の揮発性順序（Order of Volatility）</h3>
<p>レジスタ／キャッシュ → <strong class="k">メモリ（RAM）</strong> → ネットワーク状態・一時ファイル → ディスク → リモートログ → 物理媒体・バックアップ</p>
<p>揮発性の高いものから先に採取する。</p>

<h3>証拠の種類と要件</h3>
<div class="tablewrap"><table>
<thead><tr><th>用語</th><th>意味</th></tr></thead>
<tbody>
<tr><td><strong class="k">Chain of Custody</strong></td><td>誰が・いつ・何を・どこで扱ったかの連続記録。<strong>これが切れると証拠能力を失う</strong></td></tr>
<tr><td>Best Evidence Rule</td><td>原本が最良。デジタルでは<strong>ハッシュ検証済みのビットイメージ</strong>が原本相当</td></tr>
<tr><td>Direct / Real / Documentary / Demonstrative</td><td>直接証拠／物的証拠／文書証拠／説明用証拠</td></tr>
<tr><td>Hearsay Rule</td><td>伝聞は原則不可。ただし<strong>業務上通常記録されるログ</strong>は例外になりうる</td></tr>
<tr><td>証拠の5要件</td><td>Accurate / Complete / Authentic / Convincing / Admissible</td></tr>
</tbody></table></div>

<h3>調査の種類と立証基準</h3>
<div class="tablewrap"><table>
<thead><tr><th>種別</th><th>立証基準</th><th>結果</th></tr></thead>
<tbody>
<tr><td>刑事（Criminal）</td><td><strong class="k">合理的な疑いを超える</strong></td><td>拘禁・罰金</td></tr>
<tr><td>民事（Civil）</td><td><strong class="k">証拠の優越</strong>（51%）</td><td>損害賠償</td></tr>
<tr><td>行政・規制（Regulatory）</td><td>より緩やかな基準</td><td>制裁金・業務改善命令</td></tr>
<tr><td>内部（Administrative）</td><td>組織の定めによる</td><td>懲戒</td></tr>
</tbody></table></div>

<h3>検知の指標</h3>
<ul>
<li><strong>MTTD</strong>（平均検知時間）／<strong>MTTR</strong>（平均対応時間）／<strong>Dwell Time</strong>（滞留時間）— 短縮が被害額に直結</li>
<li><strong>IDS vs IPS</strong>：IDS は検知のみ、IPS はインラインで遮断（誤検知が業務を止めるリスク）</li>
<li><strong>シグネチャ検知</strong>＝既知に強く未知に弱い／<strong>アノマリ検知</strong>＝未知を検知できるが誤検知が多く<strong>ベースライン学習が前提</strong></li>
<li><strong>UEBA</strong>：正規資格情報の悪用（内部不正・乗っ取り）の検知に有効</li>
<li><strong>SOAR</strong>：対応の自動化。アラート疲れ（alert fatigue）対策</li>
</ul>
"""),

("cs-ops", "運用・バックアップ", "RAID・バックアップ方式・変更管理", """
<h3>RAID レベル</h3>
<div class="tablewrap"><table>
<thead><tr><th>RAID</th><th>方式</th><th>最小台数</th><th>耐障害</th><th>容量効率</th></tr></thead>
<tbody>
<tr><td>0</td><td>ストライピング</td><td>2</td><td><strong class="k">なし</strong></td><td>100%</td></tr>
<tr><td>1</td><td>ミラーリング</td><td>2</td><td>1台</td><td>50%</td></tr>
<tr><td>5</td><td>分散パリティ</td><td>3</td><td>1台</td><td>(n−1)/n</td></tr>
<tr><td>6</td><td>ダブルパリティ</td><td>4</td><td><strong>2台</strong></td><td>(n−2)/n</td></tr>
<tr><td>10 (1+0)</td><td>ミラー＋ストライプ</td><td>4</td><td>グループごと1台</td><td>50%</td></tr>
</tbody></table></div>
<div class="callout exam"><span class="lab">最頻出</span><strong class="k">RAID はバックアップの代替にならない。</strong>誤削除・ランサムウェア・論理破損はミラーされるだけ。</div>

<h3>バックアップ方式</h3>
<div class="tablewrap"><table>
<thead><tr><th>方式</th><th>取得対象</th><th>取得時間</th><th>復旧時に必要なもの</th></tr></thead>
<tbody>
<tr><td>フル</td><td>全データ</td><td>最長</td><td>フル 1本</td></tr>
<tr><td><strong>差分</strong>(Differential)</td><td>前回<strong>フル</strong>以降の変更</td><td>日々増加</td><td>フル ＋ <strong class="k">最新の差分1本</strong></td></tr>
<tr><td><strong>増分</strong>(Incremental)</td><td>前回<strong>バックアップ</strong>以降の変更</td><td>最短</td><td>フル ＋ <strong class="k">全ての増分</strong></td></tr>
</tbody></table></div>
<p>覚え方：<strong>差分は取得が遅く復旧が速い／増分は取得が速く復旧が遅い</strong>。</p>

<h3>3-2-1（-1-0）ルール</h3>
<p><strong>3</strong> つのコピー／<strong>2</strong> 種類の媒体／<strong>1</strong> つはオフサイト<br>
＋ <strong>1</strong> つはオフライン or 改変不可（immutable）／<strong>0</strong> 件のエラー（<strong class="k">復旧テスト済み</strong>）</p>

<h3>変更管理 / 構成管理</h3>
<div class="tablewrap"><table>
<thead><tr><th></th><th>目的</th><th>要点</th></tr></thead>
<tbody>
<tr><td><strong>変更管理</strong></td><td>変更を統制する</td><td>要求 → 影響分析 → 承認(CAB) → テスト → 実施 → 検証 → 記録。<strong class="k">ロールバック手順は必須</strong></td></tr>
<tr><td><strong>構成管理</strong></td><td>現状を正しく把握する</td><td>ベースライン定義、CMDB、構成ドリフトの検知</td></tr>
<tr><td>緊急変更</td><td>速度と統制の両立</td><td><strong>平時に手順を定義</strong>し、簡略承認＋事後レビュー</td></tr>
<tr><td>パッチ管理</td><td>脆弱性の解消</td><td>優先順位（深刻度×資産重要度）→ テスト → 段階展開 → 検証</td></tr>
</tbody></table></div>

<h3>運用の基礎概念</h3>
<ul>
<li><strong>Least Privilege</strong> / <strong>Need to Know</strong> / <strong>Separation of Duties</strong>（工程を分ける）/ <strong>Dual Control</strong>（同時2人）</li>
<li><strong>Job Rotation</strong>（不正の<strong class="k">発見</strong>）/ <strong>Mandatory Vacation</strong>（隠蔽の<strong class="k">露見</strong>）</li>
<li><strong>Graceful Degradation</strong>（縮退運転）／<strong>Fail Soft</strong>／<strong>Fault Tolerance</strong></li>
<li><strong>責任共有モデル</strong>：IaaS＝OS より上が利用者／PaaS＝アプリとデータ／SaaS＝データ・ID・設定。<strong class="k">データと ID は常に利用者責任</strong></li>
</ul>
"""),

("cs-legal", "法規制とプライバシー", "GDPR・知財・監査報告書", """
<h3>知的財産の4分類</h3>
<div class="tablewrap"><table>
<thead><tr><th>種類</th><th>保護対象</th><th>期間</th><th>登録</th></tr></thead>
<tbody>
<tr><td><strong>特許</strong>(Patent)</td><td>発明（新規性・進歩性・有用性）</td><td>一般に20年</td><td>必要（公開が対価）</td></tr>
<tr><td><strong>著作権</strong>(Copyright)</td><td>表現（アイデアではない）</td><td>著作者の死後70年など</td><td>不要（自動発生）</td></tr>
<tr><td><strong>商標</strong>(Trademark)</td><td>識別標識（ロゴ・名称）</td><td>更新すれば無期限</td><td>推奨</td></tr>
<tr><td><strong class="k">営業秘密</strong>(Trade Secret)</td><td>秘密として管理される情報</td><td><strong>無期限（秘密である限り）</strong></td><td>不要</td></tr>
</tbody></table></div>

<h3>GDPR の押さえどころ</h3>
<ul>
<li><strong class="k">侵害通知は認識から72時間以内</strong>に監督機関へ。高リスクならデータ主体にも遅滞なく</li>
<li>制裁金：最大 <strong>全世界年間売上の4%</strong> または 2000万ユーロのいずれか高い方</li>
<li>役割：<strong>Controller</strong>（目的と手段を決定）／<strong>Processor</strong>（委託で処理）／<strong>Data Subject</strong>（本人）／<strong>DPO</strong>（独立した監督・助言）</li>
<li>原則：適法性・目的の限定・<strong>データ最小化</strong>・正確性・保存期間の制限・完全性と機密性・<strong>アカウンタビリティ</strong></li>
<li>権利：アクセス・訂正・<strong>消去（忘れられる権利）</strong>・処理制限・<strong>データポータビリティ</strong>・異議申立て</li>
<li>設計原則：<strong class="k">Privacy by Design / by Default</strong></li>
<li>越境移転：十分性認定 / SCC / BCR。<strong>暗号化は移転根拠にならない</strong></li>
</ul>

<h3>主要な法令・基準</h3>
<div class="tablewrap"><table>
<thead><tr><th>名称</th><th>領域</th><th>性質</th></tr></thead>
<tbody>
<tr><td>GDPR</td><td>EU 個人データ保護</td><td>法律</td></tr>
<tr><td>個人情報保護法（APPI）</td><td>日本の個人情報</td><td>法律</td></tr>
<tr><td>HIPAA</td><td>米国 医療情報（PHI）</td><td>法律</td></tr>
<tr><td>SOX</td><td>米国 財務報告の内部統制</td><td>法律</td></tr>
<tr><td>GLBA</td><td>米国 金融機関の顧客情報</td><td>法律</td></tr>
<tr><td>FISMA</td><td>米国連邦機関の情報セキュリティ</td><td>法律</td></tr>
<tr><td><strong class="k">PCI DSS</strong></td><td>カード会員データ</td><td><strong>契約に基づく業界標準（法律ではない）</strong></td></tr>
<tr><td>ISO/IEC 27001</td><td>ISMS 要求事項</td><td><strong>認証対象</strong></td></tr>
<tr><td>ISO/IEC 27002</td><td>管理策の実践規範</td><td>ガイダンス（認証対象外）</td></tr>
<tr><td>ISO/IEC 27701</td><td>プライバシー情報管理（PIMS）</td><td>27001 の拡張</td></tr>
<tr><td>NIST CSF</td><td>Identify/Protect/Detect/Respond/Recover（＋Govern）</td><td>任意フレームワーク</td></tr>
<tr><td>NIST SP 800-53</td><td>米国連邦の管理策カタログ</td><td>統制集</td></tr>
</tbody></table></div>

<h3>SOC レポート</h3>
<div class="tablewrap"><table>
<thead><tr><th></th><th>対象</th><th>公開範囲</th></tr></thead>
<tbody>
<tr><td>SOC 1</td><td>財務報告に関する内部統制</td><td>限定（NDA）</td></tr>
<tr><td><strong class="k">SOC 2</strong></td><td>Trust Services 基準（セキュリティ／可用性／処理の完全性／機密性／プライバシー）</td><td>限定（NDA）</td></tr>
<tr><td>SOC 3</td><td>SOC 2 の要約</td><td><strong>一般公開可</strong></td></tr>
</tbody></table></div>
<p><strong class="k">Type I ＝ある時点の「設計」／Type II ＝一定期間（6〜12か月）の「運用有効性」</strong>。ベンダー評価では Type II を求めるのが原則。</p>

<h3>用語の対比</h3>
<ul>
<li><strong>Due Diligence</strong>＝調べる（Discover）／<strong>Due Care</strong>＝実際に手を打つ（Correct）</li>
<li><strong>Prudent Person Rule</strong>：合理的な人が取るであろう措置を怠れば過失を問われうる</li>
<li><strong>PII</strong>（個人識別情報）／<strong>PHI</strong>（医療情報）／<strong>SPI</strong>（機微情報）</li>
</ul>
"""),

("cs-dev", "開発セキュリティ", "SDLC・OWASP・成熟度モデル", """
<h3>SDLC とセキュリティ活動</h3>
<div class="tablewrap"><table>
<thead><tr><th>フェーズ</th><th>セキュリティ活動</th></tr></thead>
<tbody>
<tr><td>要件定義</td><td>セキュリティ要件の定義、法規制の特定、プライバシー要件</td></tr>
<tr><td><strong class="k">設計</strong></td><td><strong>脅威モデリング（STRIDE）</strong>、セキュア設計原則の適用、アーキテクチャレビュー</td></tr>
<tr><td>実装</td><td>セキュアコーディング、<strong>SAST</strong>、SCA、シークレットスキャン、ピアレビュー</td></tr>
<tr><td>テスト</td><td><strong>DAST</strong>、IAST、ファジング、ペネトレーションテスト</td></tr>
<tr><td>展開</td><td>ハードニング、設定検証、成果物の署名</td></tr>
<tr><td>運用</td><td>監視、パッチ管理、脆弱性管理、RASP</td></tr>
<tr><td><strong>廃棄</strong></td><td>データの安全な移行／破棄、<strong class="k">アカウント・連携の失効</strong></td></tr>
</tbody></table></div>
<div class="callout tip"><span class="lab">Shift Left</span>欠陥の修正コストは後工程ほど<strong class="k">指数的に増大</strong>する。要件・設計段階でのセキュリティ投入が最も費用対効果が高い。</div>

<h3>テスト手法の比較</h3>
<div class="tablewrap"><table>
<thead><tr><th></th><th>SAST</th><th>DAST</th><th>IAST</th></tr></thead>
<tbody>
<tr><td>対象</td><td>ソース／バイナリ</td><td>実行中のアプリ</td><td>実行中（内部エージェント）</td></tr>
<tr><td>実施時期</td><td>開発初期</td><td>テスト以降</td><td>テスト以降</td></tr>
<tr><td>誤検知</td><td><strong class="k">多い</strong></td><td>少ない</td><td>少ない</td></tr>
<tr><td>コード位置の特定</td><td>可能</td><td><strong class="k">困難</strong></td><td>可能</td></tr>
</tbody></table></div>
<p>他に <strong>SCA</strong>（依存ライブラリの脆弱性・ライセンス）、<strong>ファジング</strong>（異常入力の大量投入）、<strong>回帰テスト</strong>（変更で壊れていないか）、<strong>ミスユースケース</strong>（悪用シナリオの検証）。</p>

<h3>開発手法</h3>
<ul>
<li><strong>ウォーターフォール</strong>：順次進行。要件が安定している場合に有効</li>
<li><strong>スパイラル</strong>：各サイクルで<strong class="k">リスク分析</strong>を行う反復型</li>
<li><strong>アジャイル</strong>：短い反復。セキュリティは<strong>バックログと Definition of Done に組み込む</strong></li>
<li><strong>DevOps / DevSecOps</strong>：CI/CD に自動セキュリティ検査を統合。「ゲートからガードレールへ」</li>
</ul>

<h3>CMMI（成熟度レベル）</h3>
<ol>
<li><strong>Initial</strong> — 場当たり的、属人的</li>
<li><strong>Managed</strong>（Repeatable）— プロジェクト単位で管理</li>
<li><strong class="k">Defined</strong> — 組織標準プロセスとして定義</li>
<li><strong>Quantitatively Managed</strong> — 定量的に測定・制御</li>
<li><strong>Optimizing</strong> — 継続的改善</li>
</ol>
<p>ソフトウェア保証に特化したモデル：<strong>SAMM</strong>（規範的）／<strong>BSIMM</strong>（実測に基づく記述的）</p>

<h3>OWASP Top 10 の代表と対策</h3>
<div class="tablewrap"><table>
<thead><tr><th>脆弱性</th><th>根本対策</th></tr></thead>
<tbody>
<tr><td>Broken Access Control（IDOR 含む）</td><td>サーバ側で毎回認可を検証。デフォルト拒否</td></tr>
<tr><td>Injection（SQLi 等）</td><td><strong class="k">パラメタライズドクエリ</strong>＋許可リスト検証＋最小権限 DB アカウント</td></tr>
<tr><td>XSS</td><td><strong class="k">出力時のコンテキスト別エスケープ</strong>＋CSP</td></tr>
<tr><td>CSRF</td><td>CSRF トークン＋SameSite Cookie</td></tr>
<tr><td>Cryptographic Failures</td><td>強い暗号・適切な鍵管理・平文保存の排除</td></tr>
<tr><td>Insecure Design</td><td>脅威モデリング、セキュア設計原則</td></tr>
<tr><td>Vulnerable Components</td><td><strong>SCA / SBOM</strong> による依存の可視化と更新</td></tr>
<tr><td>SSRF</td><td>送信先の許可リスト、メタデータエンドポイントの遮断</td></tr>
<tr><td>Security Misconfiguration</td><td>ハードニング基準、既定値の変更、不要機能の無効化</td></tr>
<tr><td>Logging &amp; Monitoring Failures</td><td>監査可能なログ設計と集中監視</td></tr>
</tbody></table></div>

<h3>その他の重要語</h3>
<ul>
<li><strong>環境分離</strong>：開発／テスト／本番。<strong class="k">開発者が本番へ直接デプロイできる状態は職務分掌違反</strong></li>
<li><strong>テストデータ</strong>：本番データの無加工利用は不可。マスキング／匿名化／合成データ</li>
<li><strong>ソフトウェアエスクロー</strong>：ベンダー破綻に備えたソースコードの第三者預託</li>
<li><strong>責任共有モデル</strong>：クラウド利用時の責任範囲の確認</li>
<li><strong>TOCTOU</strong>：検証と使用の間の競合状態（race condition）</li>
</ul>
"""),

("cs-physical", "物理セキュリティ", "施設・電源・消火・CPTED", """
<h3>CPTED（環境設計による犯罪予防）</h3>
<ul>
<li><strong>Natural Surveillance</strong>（自然監視）：見通しの確保、照明</li>
<li><strong>Natural Access Control</strong>（自然なアクセス制御）：導線設計、植栽、入口の限定</li>
<li><strong>Territorial Reinforcement</strong>（領域性の強化）：所有感の明示、境界の可視化</li>
</ul>

<h3>境界防御の階層</h3>
<p>フェンス → 門・照明 → 建物外壁 → 受付 → <strong class="k">マントラップ</strong> → サーバルーム → ラック</p>
<div class="tablewrap"><table>
<thead><tr><th>統制</th><th>用途</th></tr></thead>
<tbody>
<tr><td>フェンス高</td><td>1m 程度＝抑止／2m 超＝一般的侵入を困難に／2.4m＋有刺鉄線＝本格的侵入者を阻止</td></tr>
<tr><td><strong>マントラップ</strong>（Access Control Vestibule）</td><td>二重扉で一度に一人。<strong class="k">共連れ（tailgating/piggybacking）対策</strong></td></tr>
<tr><td>ターンスタイル</td><td>一方向・一人ずつの通行</td></tr>
<tr><td>ボラード</td><td>車両突入の防止</td></tr>
<tr><td>警備員</td><td>唯一「判断」ができる統制。ただし高コスト・人的過失</td></tr>
<tr><td>CCTV</td><td>検知的統制。<strong>その場の侵入は防げない</strong></td></tr>
</tbody></table></div>

<h3>電源の用語</h3>
<div class="tablewrap"><table>
<thead><tr><th>用語</th><th>意味</th></tr></thead>
<tbody>
<tr><td>Blackout</td><td>完全な停電</td></tr>
<tr><td>Brownout</td><td>電圧低下の継続</td></tr>
<tr><td>Sag / Dip</td><td>瞬間的な電圧低下</td></tr>
<tr><td>Spike / Surge</td><td>瞬間的／継続的な電圧上昇</td></tr>
<tr><td>Fault</td><td>瞬間的な停電</td></tr>
<tr><td>Noise / EMI</td><td>電気的な雑音</td></tr>
</tbody></table></div>
<p><strong class="k">UPS</strong>＝短時間の電力供給と品質安定 → 長時間は<strong>発電機</strong>へ引き継ぐ。</p>

<h3>火災の分類と消火剤</h3>
<div class="tablewrap"><table>
<thead><tr><th>Class（米）</th><th>燃焼物</th><th>適切な消火</th></tr></thead>
<tbody>
<tr><td>A</td><td>普通可燃物（木・紙・布）</td><td>水、ソーダ酸</td></tr>
<tr><td>B</td><td>可燃性液体（油・溶剤）</td><td>CO2、泡、乾燥粉末</td></tr>
<tr><td><strong class="k">C</strong></td><td><strong>電気設備</strong></td><td>CO2、<strong>クリーンエージェント（水は不可）</strong></td></tr>
<tr><td>D</td><td>可燃性金属</td><td>専用乾燥粉末</td></tr>
<tr><td>K（欧州 F）</td><td>厨房油脂</td><td>湿性化学剤</td></tr>
</tbody></table></div>
<p>サーバルームの消火：<strong class="k">クリーンエージェント（FM-200、Novec 1230、不活性ガス）</strong>が残渣を残さず機器を損傷しない。<strong>ハロンはオゾン層破壊のため新規使用禁止</strong>。<br>
水系なら <strong>Pre-action（予作動式）</strong>が誤放水リスクを下げる。ただし<strong class="k">人命が常に最優先</strong>で、避難と酸素濃度への配慮が必要。</p>

<h3>環境</h3>
<ul>
<li>温度・湿度の管理（低湿度＝静電気、高湿度＝結露・腐食）</li>
<li><strong>ホットアイル／コールドアイル</strong>による空調効率化</li>
<li><strong>正圧</strong>を維持して汚染物質・煙の侵入を防ぐ</li>
<li><strong>TEMPEST</strong>：電磁波漏えい対策（シールド、ファラデーケージ、ホワイトノイズ）</li>
</ul>
"""),

("cs-confuse", "紛らわしいペア", "取り違え頻出の対比", """
<div class="tablewrap"><table>
<thead><tr><th>A</th><th>B</th><th>決定的な違い</th></tr></thead>
<tbody>
<tr><td>Due Diligence</td><td>Due Care</td><td><strong>調べる</strong>／<strong>実行する</strong></td></tr>
<tr><td>Responsibility</td><td><strong class="k">Accountability</strong></td><td>委譲できる／<strong>委譲できない</strong></td></tr>
<tr><td>Policy</td><td>Standard</td><td>高レベルの意思／具体的で強制力のある要件</td></tr>
<tr><td>Standard</td><td>Guideline</td><td>強制（must）／<strong>推奨（should）</strong></td></tr>
<tr><td>Baseline</td><td>Guideline</td><td>下回ってはならない最低水準／任意の推奨</td></tr>
<tr><td>MTD</td><td>RTO</td><td>事業が耐えられる限界／復旧の目標。<strong>RTO ≦ MTD</strong></td></tr>
<tr><td>RTO</td><td>RPO</td><td>時間軸の「復旧まで」／「さかのぼれる時点＝データ損失量」</td></tr>
<tr><td>BCP</td><td>DRP</td><td>事業全体／<strong>IT 復旧（BCP の下位）</strong></td></tr>
<tr><td>差分バックアップ</td><td>増分バックアップ</td><td>フル以降の全変更（復旧が速い）／前回以降のみ（取得が速い）</td></tr>
<tr><td>BLP</td><td>Biba</td><td>機密性（No Read Up / No Write Down）／完全性（<strong>逆</strong>）</td></tr>
<tr><td>DAC</td><td>MAC</td><td>所有者の裁量／システムが強制（所有者も変更不可）</td></tr>
<tr><td>RBAC</td><td>ABAC</td><td>役割のみ／属性＋環境（時刻・端末・場所）</td></tr>
<tr><td>Authentication</td><td>Authorization</td><td>本人であることの証明／何をしてよいかの決定</td></tr>
<tr><td>FRR (Type I)</td><td>FAR (Type II)</td><td>本人を拒否（利便性）／<strong class="k">他人を受入（セキュリティ）</strong></td></tr>
<tr><td>SAML</td><td>OAuth 2.0</td><td>認証情報の連携（SSO）／<strong class="k">認可の委譲</strong></td></tr>
<tr><td>OAuth 2.0</td><td>OIDC</td><td>認可のみ／その上に ID トークンで<strong>認証</strong>を追加</td></tr>
<tr><td>HMAC</td><td>デジタル署名</td><td>完全性＋真正性（<strong class="k">否認防止なし</strong>）／否認防止あり</td></tr>
<tr><td>AH</td><td>ESP</td><td>完全性・真正性のみ／<strong>機密性も提供</strong></td></tr>
<tr><td>IDS</td><td>IPS</td><td>検知のみ／インラインで<strong>遮断</strong></td></tr>
<tr><td>脆弱性スキャン</td><td>ペネトレーションテスト</td><td>広く浅く検出／<strong>実際に悪用して実証</strong></td></tr>
<tr><td>SAST</td><td>DAST</td><td>実行せずコード解析（誤検知多）／実行中に外部から（位置特定困難）</td></tr>
<tr><td>SOC 2 Type I</td><td>SOC 2 Type II</td><td>ある時点の設計／<strong class="k">一定期間の運用有効性</strong></td></tr>
<tr><td>変更管理</td><td>構成管理</td><td>変え方を統制／現状を正しく把握</td></tr>
<tr><td>Job Rotation</td><td>Separation of Duties</td><td>不正の<strong>発見</strong>／不正の<strong>防止</strong></td></tr>
<tr><td>Separation of Duties</td><td>Dual Control</td><td>工程を分けて別人に／同一作業に2人同時</td></tr>
<tr><td>Fail Safe</td><td>Fail Secure</td><td><strong class="k">人命優先＝開放</strong>／機密優先＝閉鎖</td></tr>
<tr><td>Clear</td><td>Purge / Destroy</td><td>上書き（同種再利用可）／消磁・暗号消去／物理破壊</td></tr>
<tr><td>暗号化</td><td>トークナイゼーション</td><td>鍵で復号可能／対応表を Vault に保持（PCI スコープ縮小）</td></tr>
<tr><td>EOL</td><td><strong class="k">EOS</strong></td><td>販売終了／<strong>パッチ提供終了（より深刻）</strong></td></tr>
<tr><td>Awareness</td><td>Training</td><td>注意喚起（What・全員）／技能習得（How・職務別）</td></tr>
<tr><td>KRI</td><td>KPI</td><td>リスク増大の<strong>先行</strong>指標／目標達成の<strong>成果</strong>指標</td></tr>
<tr><td>Inherent Risk</td><td>Residual Risk</td><td>統制前のリスク／統制後に残るリスク</td></tr>
<tr><td>Risk Appetite</td><td>Risk Tolerance</td><td>取りにいく水準／許容できる変動幅</td></tr>
</tbody></table></div>
"""),

("cs-numbers", "数字で覚える", "試験で問われる数値まとめ", """
<div class="tablewrap"><table>
<thead><tr><th>数値</th><th>意味</th></tr></thead>
<tbody>
<tr><td><strong class="k">700 / 1000</strong></td><td>CISSP 合格点</td></tr>
<tr><td>100〜150 問／3時間</td><td>現行 CISSP CAT の出題数と試験時間（うち25問は採点対象外の事前問題）</td></tr>
<tr><td>16 / 10 / 13 / 13 / 13 / 12 / 13 / 10 %</td><td>D1〜D8 の出題比率</td></tr>
<tr><td>5年</td><td>CISSP 受験に必要な実務経験（2ドメイン以上、学位等で1年免除）</td></tr>
<tr><td>120 CPE / 3年</td><td>資格維持に必要な継続教育（年40が目安）</td></tr>
<tr><td><strong class="k">72時間</strong></td><td>GDPR の侵害通知期限（監督機関へ）</td></tr>
<tr><td>4% または 2000万ユーロ</td><td>GDPR 制裁金の上限（高い方）</td></tr>
<tr><td>4つ</td><td>ISC2 倫理綱領のカノン数（<strong>順序＝優先順位</strong>）</td></tr>
<tr><td>7層 / 4層</td><td>OSI ／ TCP/IP</td></tr>
<tr><td>128 / 192 / 256 bit</td><td>AES の鍵長（ブロック長は常に128、ラウンド 10/12/14）</td></tr>
<tr><td>56 bit</td><td>DES の鍵長（危殆化）</td></tr>
<tr><td>2048 bit 以上</td><td>RSA の推奨鍵長（ECC 256 ≒ RSA 3072）</td></tr>
<tr><td>2^(n/2)</td><td>誕生日攻撃で衝突が見つかる試行回数の目安</td></tr>
<tr><td>n(n−1)/2</td><td>n 人が対称鍵で相互通信する際の鍵の本数</td></tr>
<tr><td>5分</td><td>Kerberos の既定の時刻ずれ許容範囲</td></tr>
<tr><td>30秒</td><td>TOTP の標準的な更新間隔</td></tr>
<tr><td>99.9% → 8.76時間/年</td><td>可用性の換算（99.99%＝52.6分、99.999%＝5.26分）</td></tr>
<tr><td>RAID 5 = 1台 / RAID 6 = 2台</td><td>許容できるディスク障害数</td></tr>
<tr><td>3-2-1</td><td>コピー3つ・媒体2種類・オフサイト1つ</td></tr>
<tr><td>Class A/B/C/D/K</td><td>火災分類（C＝電気設備）</td></tr>
<tr><td>1 → 5</td><td>CMMI のレベル数（3 = Defined が組織標準化の分水嶺）</td></tr>
<tr><td>6段階</td><td>インシデント対応フェーズ（準備→検知分析→封じ込め→根絶→復旧→教訓）</td></tr>
<tr><td>5段階</td><td>DR テストの強度（Checklist → Walk-through → Simulation → Parallel → Full Interruption）</td></tr>
</tbody></table></div>
"""),
]
