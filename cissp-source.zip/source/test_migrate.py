#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prove that upgrading the app preserves every learner's progress:
   1. old (hash-ID) save data survives the move to permanent IDs
   2. rewording a question keeps its ID, so its history is not lost
   3. adding a question leaves everything else untouched
"""
import json, hashlib, re, sys, subprocess, os, shutil
from playwright.sync_api import sync_playwright

HERE = "/home/claude/build"
APP = "file:///mnt/user-data/outputs/CISSP.html"
ok = True
def check(label, cond, extra=""):
    global ok
    print(("  PASS  " if cond else "  FAIL  ") + label + ("" if cond else "   " + str(extra)))
    if not cond: ok = False

def norm(s):
    return re.sub(r'\s+', '', re.sub(r'<[^>]+>', '', s or '')).lower()

P = json.load(open(os.path.join(HERE, "payload.json"), encoding="utf-8"))
QS = P["questions"]

# ---- build a v1-shaped save file, keyed the old way -------------------------
sample = QS[:40]
legacy = {"v": 1, "q": {}, "c": {}, "read": {}, "sess": [], "hist": {},
          "flagQ": [], "flagC": [], "mock": None,
          "set": {"theme": "dark", "examDate": "", "goal": 20, "timer": 1, "sound": 0}}
expect = {}
for n, q in enumerate(sample):
    old_id = "q" + hashlib.md5(norm(q["q"]).encode()).hexdigest()[:8]
    rec = {"n": 3, "c": 2, "box": (n % 5) + 1, "due": 0, "last": 0, "ms": 9000}
    legacy["q"][old_id] = rec
    expect[q["i"]] = rec["box"]
for c in P["cards"][:15]:
    legacy["c"]["c" + hashlib.md5(norm(c["f"]).encode()).hexdigest()[:8]] = \
        {"n": 2, "box": 3, "ease": 2.5, "ivl": 6, "due": 0, "lapse": 0}
legacy["flagQ"] = ["q" + hashlib.md5(norm(q["q"]).encode()).hexdigest()[:8] for q in QS[:5]]
expect_flags = [q["i"] for q in QS[:5]]

INIT = "try{localStorage.setItem('cissp_drill_v1', %s);}catch(e){}" % json.dumps(
    json.dumps(legacy, ensure_ascii=False))

print("1) 旧バージョンの進捗が新バージョンへ引き継がれるか")
with sync_playwright() as pw:
    b = pw.chromium.launch()
    ctx = b.new_context(viewport={"width": 393, "height": 852}, is_mobile=True, has_touch=True)
    ctx.add_init_script(INIT)
    p = ctx.new_page(); errs = []
    p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(APP); p.wait_for_selector("#tabbar button", timeout=20000); p.wait_for_timeout(900)

    got = p.evaluate("""() => {
      const S = JSON.parse(localStorage.getItem('cissp_drill_v1'));
      return {v:S.v, q:S.q, nq:Object.keys(S.q).length, nc:Object.keys(S.c).length, flags:S.flagQ};
    }""")
    check("スキーマが v2 に上がった", got["v"] == 2, got["v"])
    check("問題の履歴が %d 件そのまま残った" % len(expect),
          got["nq"] == len(expect), got["nq"])
    check("カードの履歴が 15 件残った", got["nc"] == 15, got["nc"])
    bad = [k for k, v in expect.items() if k not in got["q"] or got["q"][k]["box"] != v]
    check("すべて新IDに正しく載り替わった", not bad, bad[:3])
    check("フラグも移行された", got["flags"] == expect_flags, got["flags"][:3])
    check("旧形式のキーが残っていない",
          not [k for k in got["q"] if len(k) != 5], [k for k in got["q"] if len(k) != 5][:3])

    # readiness must be non-zero, i.e. the app actually sees the migrated data
    p.click("#tabbar [data-tab='stats']"); p.wait_for_selector(".kpi")
    kpi = p.inner_text(".kpi")
    check("画面上でも進捗として認識されている", "0" != kpi.strip().split("\n")[0], kpi[:40])
    check("移行中にJSエラーなし", not errs, errs[:2])
    b.close()

# ---- 2) reword a question, rebuild, confirm the ID survives -----------------
print("\n2) 問題文を修正してもIDが変わらないか")
target = QS[10]
qb = os.path.join(HERE, "qbank_x1.py")
backup = qb + ".bak"
shutil.copy(qb, backup)
reg_backup = json.load(open(os.path.join(HERE, "ids.json"), encoding="utf-8"))
try:
    victim = None
    src = open(qb, encoding="utf-8").read()
    import qbank_x1_probe  # noqa  (placeholder to keep linters quiet)
except ImportError:
    pass
try:
    src = open(qb, encoding="utf-8").read()
    # pick a question that lives in qbank_x1 and tweak its wording
    m = re.search(r'\["d4","osi",2,"(TCP スリーウェイハンドシェイクの正しい順序はどれか。)"', src)
    assert m, "probe question not found"
    before = [q for q in QS if q["q"].startswith("TCP スリーウェイハンドシェイク")][0]
    src2 = src.replace(m.group(1), "TCP のスリーウェイ・ハンドシェイクの順序として正しいものはどれか。", 1)
    open(qb, "w", encoding="utf-8").write(src2)
    out = subprocess.run([sys.executable, os.path.join(HERE, "pack.py")],
                         capture_output=True, text=True, cwd=HERE)
    P2 = json.load(open(os.path.join(HERE, "payload.json"), encoding="utf-8"))
    after = [q for q in P2["questions"] if q["q"].startswith("TCP のスリーウェイ")]
    check("修正後の問題が1件見つかる", len(after) == 1, len(after))
    if after:
        check("IDが維持された（進捗が消えない）", after[0]["i"] == before["i"],
              "%s -> %s" % (before["i"], after[0]["i"]))
    check("総問題数は変わらない", len(P2["questions"]) == len(QS), len(P2["questions"]))
    check("ビルドログが「文言修正」を報告", "文言修正 1" in out.stdout, out.stdout.strip()[-160:])
finally:
    shutil.move(backup, qb)
    json.dump(reg_backup, open(os.path.join(HERE, "ids.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=0, sort_keys=True)
    subprocess.run([sys.executable, os.path.join(HERE, "make.py")],
                   capture_output=True, text=True, cwd=HERE)

# ---- 3) the restored build must be byte-identical in its IDs ----------------
print("\n3) 復元後のビルドが元どおりか")
P3 = json.load(open(os.path.join(HERE, "payload.json"), encoding="utf-8"))
check("問題数が一致", len(P3["questions"]) == len(QS), len(P3["questions"]))
check("全問のIDが一致",
      [q["i"] for q in P3["questions"]] == [q["i"] for q in QS])

print("\n" + ("ALL PASS" if ok else "FAILURES PRESENT"))
sys.exit(0 if ok else 1)
