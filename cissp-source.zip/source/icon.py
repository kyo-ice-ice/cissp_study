#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate the apple-touch-icon: an 8-arc ring (one arc per CISSP domain,
   angular width = official exam weight)."""
from PIL import Image, ImageDraw
import base64, io, os

W = {"d1":16,"d2":10,"d3":13,"d4":13,"d5":13,"d6":12,"d7":13,"d8":10}
C = ["#6E8FF0","#4FB0D6","#3FBFA0","#7CC24C","#E0B23C","#EE8C43","#E85D6B","#B47AE4"]
ORDER = ["d1","d2","d3","d4","d5","d6","d7","d8"]

SS = 8          # supersample
S = 180
N = S * SS
img = Image.new("RGBA", (N, N), (13, 19, 27, 255))
d = ImageDraw.Draw(img)

# rounded-square ground with a subtle inner panel
pad = int(N * 0.0)
d.rounded_rectangle([pad, pad, N - pad - 1, N - pad - 1], radius=int(N * 0.225), fill=(13, 19, 27, 255))

cx = cy = N / 2
r_out = N * 0.375
thick = N * 0.115
box = [cx - r_out, cy - r_out, cx + r_out, cy + r_out]

start = -90.0
gap = 2.2
for i, k in enumerate(ORDER):
    span = W[k] / 100.0 * 360.0
    a0, a1 = start + gap / 2, start + span - gap / 2
    d.arc(box, a0, a1, fill=C[i], width=int(thick))
    start += span

# centre mark: a vermilion dot ring (the "mark this" accent)
rr = N * 0.105
d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(232, 97, 76, 255), width=int(N * 0.026))

img = img.resize((S, S), Image.LANCZOS)
buf = io.BytesIO()
img.save(buf, "PNG", optimize=True)
b64 = base64.b64encode(buf.getvalue()).decode()

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.txt")
open(out, "w").write(b64)
img.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.png"))
print("icon bytes:", len(buf.getvalue()), "| b64 len:", len(b64))
