#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inline every asset into one self-contained HTML file."""
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, "app")
OUT_DIR = "/mnt/user-data/outputs"
os.makedirs(OUT_DIR, exist_ok=True)

subprocess.check_call([sys.executable, os.path.join(HERE, "pack.py")])

payload = json.load(open(os.path.join(HERE, "payload.json"), encoding="utf-8"))
svgcss = payload.pop("svgcss", "")
data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

# The payload lives inside <script type="application/json">; only "</script"
# can terminate it, so escape that sequence (and lone U+2028/9 for old parsers).
data = data.replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

shell = open(os.path.join(APP, "shell.html"), encoding="utf-8").read()
css = open(os.path.join(APP, "app.css"), encoding="utf-8").read()
js = open(os.path.join(APP, "app.js"), encoding="utf-8").read()
icon = open(os.path.join(HERE, "icon.txt")).read().strip()

assert "</script" not in js.lower(), "raw </script> in app.js"

html = shell
html = html.replace("__ICON__", icon)
html = html.replace("__CSS__", css)
html = html.replace("__SVGCSS__", svgcss)
html = html.replace("__DATA__", data)
html = html.replace("__JS__", js)

assert "__" not in re.sub(r"__CISSP__", "", html).replace("_", ""), "unfilled placeholder"

# ---- 1) standalone single file (works from any browser, no server) ----------
out = os.path.join(OUT_DIR, "CISSP.html")
open(out, "w", encoding="utf-8").write(html)
print("built %s  (%.0f KB)" % (out, os.path.getsize(out) / 1024))

# ---- 2) hosted variant: real manifest + service worker (installable PWA) ----
BLOB_MANIFEST_START = '<script>\n/* PWA manifest, generated at runtime so the file stays fully self-contained. */'
i = html.index(BLOB_MANIFEST_START)
j = html.index("</script>", i) + len("</script>")
hosted = html[:i] + """<script>
/* Registered only over http(s); a service worker cannot run from file://. */
(function () {
  if (!("serviceWorker" in navigator)) return;
  if (location.protocol !== "http:" && location.protocol !== "https:") return;
  window.addEventListener("load", function () {
    navigator.serviceWorker.register("sw.js").then(null, function () {});
  });
})();
</script>""" + html[j:]
hosted = hosted.replace(
  '<link rel="apple-touch-icon" href="data:image/png;base64,',
  '<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="data:image/png;base64,', 1)
assert 'rel="manifest"' in hosted and "serviceWorker" in hosted

manifest = {
  "name": "CISSP 演習帳", "short_name": "CISSP", "lang": "ja",
  "start_url": ".", "scope": ".", "display": "standalone", "orientation": "portrait",
  "background_color": "#0D131B", "theme_color": "#0D131B",
  "description": "CISSP 自己学習ドリル — 問題演習・単語カード・教科書・模擬試験",
  "icons": [{"src": "data:image/png;base64," + icon, "sizes": "180x180",
             "type": "image/png", "purpose": "any"}]
}
open(os.path.join(OUT_DIR, "index.html"), "w", encoding="utf-8").write(hosted)
open(os.path.join(OUT_DIR, "sw.js"), "w", encoding="utf-8").write(
    open(os.path.join(APP, "sw.js"), encoding="utf-8").read())
json.dump(manifest, open(os.path.join(OUT_DIR, "manifest.webmanifest"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
for f in ["index.html", "sw.js", "manifest.webmanifest"]:
    print("  hosted/%-22s %6.0f KB" % (f, os.path.getsize(os.path.join(OUT_DIR, f)) / 1024))
