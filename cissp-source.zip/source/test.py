#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Drive the built app in an iPhone-sized WebKit/Chromium context and assert it works."""
import sys, json, os
from playwright.sync_api import sync_playwright

APP = "file:///mnt/user-data/outputs/CISSP.html"
SHOT = "/home/claude/build/shots"
os.makedirs(SHOT, exist_ok=True)

errors, logs = [], []

def run(pw, engine):
    del errors[:]; del logs[:]
    browser = getattr(pw, engine).launch()
    ctx = browser.new_context(
        viewport={"width": 393, "height": 852},   # iPhone 15 Pro logical px
        device_scale_factor=3, is_mobile=True, has_touch=True,
        user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    )
    page = ctx.new_page()
    page.on("pageerror", lambda e: errors.append("PAGEERROR: %s" % e))
    page.on("console", lambda m: (logs.append(m.text), errors.append("CONSOLE-ERR: " + m.text)) if m.type == "error" else logs.append(m.text))

    page.goto(APP)
    page.wait_for_selector("#tabbar button", timeout=15000)
    page.wait_for_timeout(400)
    assert page.locator("#boot").count() == 0, "boot overlay not removed"

    def step(name, shot=False):
        page.wait_for_timeout(160)
        if shot: page.screenshot(path="%s/%s-%s.png" % (SHOT, engine, name), full_page=False)
        if errors: raise AssertionError("[%s] JS errors at '%s': %s" % (engine, name, errors[:4]))
        g = page.evaluate("""() => {
          const d=document.documentElement;
          const y0=window.scrollY; let ok=true;
          if(d.scrollHeight > d.clientHeight + 30){ window.scrollTo(0,120); ok = window.scrollY>0; window.scrollTo(0,y0); }
          return {ovf: d.scrollWidth - d.clientWidth, scrollable: ok};
        }""")
        assert g["ovf"] <= 1, "[%s] horizontal overflow %spx at '%s'" % (engine, g["ovf"], name)
        assert g["scrollable"], "[%s] page will not scroll vertically at '%s'" % (engine, name)

    # ---- home
    step("01-home", True)
    assert "到達度" in page.inner_text("#view")
    assert page.locator(".octa path").count() > 16, "octagon not drawn"

    # ---- quick quiz: answer 10 questions, mixing right and wrong
    page.click("[data-go='quiz'][data-mode='quick']")
    page.wait_for_selector(".opt")
    step("02-quiz", True)
    assert page.locator("#tabbar").get_attribute("class").find("hide") >= 0, "tab bar must hide during quiz"
    for i in range(10):
        page.wait_for_selector(".opt")
        n = page.locator(".opt").count()
        assert n >= 3, "options missing"
        page.locator(".opt").nth(i % n).click()
        page.click("[data-check]")
        page.wait_for_selector(".verdict")
        if i == 0: step("03-answered", True)
        page.wait_for_timeout(90)
        page.click("[data-next]")
        page.wait_for_timeout(120)
    page.wait_for_selector(".result-ring", timeout=8000)
    step("04-result", True)
    assert "問正解" in page.inner_text("#view")

    # ---- flag + explanation link into the textbook
    page.click("[data-go='drill']")
    page.wait_for_selector("[data-mode='new']")
    step("05-drill", True)
    page.click("[data-go='quiz'][data-mode='new']")
    page.wait_for_selector(".opt")
    page.click("[data-flag]")
    page.wait_for_timeout(120)
    page.locator(".opt").first.click()
    page.click("[data-check]")
    page.wait_for_selector(".expl")
    page.locator(".expl [data-go='readsec']").first.click()
    page.wait_for_selector(".doc")
    step("06-readsec-from-expl", True)
    assert page.locator(".doc").inner_text().strip() != ""

    # ---- back from the textbook returns into the same question
    page.click("[data-back]")
    page.wait_for_selector(".opt")
    assert page.locator(".expl").count() == 1, "returning from the textbook must restore the answered state"
    # leave the quiz properly
    page.click("[data-quit]")
    page.wait_for_selector("[data-mok]")
    page.click("[data-mok]")
    page.wait_for_selector(".result-ring", timeout=8000)
    page.wait_for_timeout(200)

    # ---- flashcards
    page.click("#tabbar [data-tab='cards']")
    page.wait_for_selector("[data-go='cardrun']")
    step("07-cards", True)
    page.click("[data-go='cardrun'][data-mode='mix']")
    page.wait_for_selector(".fcard")
    for i in range(6):
        page.click(".fcard")
        page.wait_for_selector(".grades")
        if i == 0: step("08-card-back", True)
        page.locator(".grades button").nth(i % 4).click()
        page.wait_for_timeout(120)
    page.click("[data-quitcard]")
    page.wait_for_timeout(200)

    # ---- written recall
    page.click("[data-go='recall']")
    page.wait_for_selector("[data-recall='show']")
    page.click("[data-recall='show']")
    page.wait_for_selector(".expl")
    step("09-recall", True)
    page.click("[data-recall='next']")
    page.wait_for_timeout(150)
    page.click("[data-quitrecall]")
    page.wait_for_timeout(200)

    # ---- reading: every domain, every section renders
    page.click("#tabbar [data-tab='read']")
    page.wait_for_selector("[data-go='readdom']")
    step("10-read", True)
    ndom = page.locator("[data-go='readdom']").count()
    assert ndom == 8, "expected 8 domains, got %d" % ndom
    for di in range(8):
        page.click("#tabbar [data-tab='read']")
        page.wait_for_selector("[data-go='readdom']")
        page.locator("[data-go='readdom']").nth(di).click()
        page.wait_for_selector("[data-go='readsec']")
        nsec = page.locator("[data-go='readsec']").count()
        for si in range(nsec):
            page.locator("[data-go='readsec']").nth(si).click()
            page.wait_for_selector(".doc")
            txt = page.locator(".doc").inner_text()
            assert len(txt) > 40, "empty section d%d s%d" % (di + 1, si)
            if errors: raise AssertionError("[%s] error in reading d%d s%d: %s" % (engine, di + 1, si, errors[:3]))
            page.click("[data-back]")
            page.wait_for_selector("[data-go='readsec']")
        if di == 0: step("11-readdom", True)

    # ---- cheat sheets: all render
    page.click("#tabbar [data-tab='read']")
    page.wait_for_selector("[data-go='cheat']")
    page.click("[data-go='cheat']")
    page.wait_for_selector("[data-go='cheatone']")
    ncheat = page.locator("[data-go='cheatone']").count()
    for ci in range(ncheat):
        page.click("#tabbar [data-tab='read']"); page.click("[data-go='cheat']")
        page.wait_for_selector("[data-go='cheatone']")
        page.locator("[data-go='cheatone']").nth(ci).click()
        page.wait_for_selector(".doc")
        assert len(page.locator(".doc").inner_text()) > 60, "empty cheat %d" % ci
        if ci == 0: step("12-cheat", True)

    # ---- search
    page.click("#tabbar [data-tab='read']")
    page.click("[data-go='search']")
    page.wait_for_selector("#sq")
    page.fill("#sq", "Kerberos")
    page.wait_for_timeout(320)
    step("13-search", True)
    assert "見つかりません" not in page.inner_text("#sres"), "Kerberos should match"
    page.fill("#sq", "RTO")
    page.wait_for_timeout(300)
    assert "見つかりません" not in page.inner_text("#sres")

    # ---- stats
    page.click("#tabbar [data-tab='stats']")
    page.wait_for_selector(".dbar")
    step("14-stats", True)
    assert page.locator(".dbar").count() >= 8

    # ---- settings + theme + export/import
    page.click("[data-go='settings']")
    page.wait_for_selector("[data-theme='light']")
    page.click("[data-theme='light']")
    page.wait_for_timeout(220)
    assert page.locator("html").get_attribute("data-theme") == "light"
    step("15-settings-light", True)
    page.click("[data-theme='dark']")
    page.wait_for_timeout(200)

    # ---- mock exam (short path): start, answer a few, quit, resume
    page.click("#tabbar [data-tab='drill']")
    page.wait_for_selector("[data-mock='50']")
    page.click("[data-mock='50']")
    page.wait_for_selector("[data-mok]")
    page.click("[data-mok]")
    page.wait_for_selector(".opt")
    assert page.locator("#timer").count() == 1, "mock exam needs a timer"
    assert page.locator(".verdict").count() == 0
    for i in range(3):
        page.locator(".opt").nth(i % 4).click()
        page.click("[data-next]")
        page.wait_for_timeout(140)
    assert page.locator(".expl").count() == 0, "mock must not reveal explanations mid-exam"
    step("16-mock", True)
    page.click("[data-quit]"); page.wait_for_selector("[data-mok]"); page.click("[data-mok]")
    page.wait_for_selector("[data-resume]")
    step("17-mock-suspended", True)
    page.click("[data-resume]")
    page.wait_for_selector(".opt")
    assert "4 /" in page.inner_text(".qmeta") or "4/" in page.inner_text(".qmeta"), "resume must restore position"
    page.click("[data-quit]"); page.wait_for_selector("[data-mok]"); page.click("[data-mok]")
    page.wait_for_timeout(200)

    # ---- persistence across reload
    page.click("#tabbar [data-tab='stats']")
    page.wait_for_selector(".kpi")
    before = page.inner_text(".kpi")
    page.reload()
    page.wait_for_selector("#tabbar button", timeout=15000)
    page.wait_for_timeout(500)
    page.click("#tabbar [data-tab='stats']")
    page.wait_for_selector(".kpi")
    after = page.inner_text(".kpi")
    assert before == after, "progress not persisted across reload:\n%s\n%s" % (before, after)
    step("18-persist", True)

    # ---- layout sanity: nothing overflows horizontally
    for tab in ["home", "drill", "cards", "read", "stats"]:
        page.click("#tabbar [data-tab='%s']" % tab)
        page.wait_for_timeout(220)
        ow = page.evaluate("() => Math.max(document.documentElement.scrollWidth, document.body.scrollWidth)")
        assert ow <= 395, "horizontal overflow on %s: %s" % (tab, ow)
        # tap targets
        small = page.evaluate("""() => {
          const bad=[];
          document.querySelectorAll('#view button, #tabbar button').forEach(b=>{
            const r=b.getBoundingClientRect();
            if(r.width>0 && r.height>0 && r.height<36) bad.push((b.textContent||'').trim().slice(0,24)+' h='+Math.round(r.height));
          });
          return bad.slice(0,5);
        }""")
        assert not small, "tap targets under 36px on %s: %s" % (tab, small)

    browser.close()
    return True

with sync_playwright() as pw:
    ok = True
    for engine in ["chromium"]:
        try:
            run(pw, engine)
            print("PASS  %s" % engine)
        except Exception as e:
            ok = False
            print("FAIL  %s: %s" % (engine, e))
            if errors: print("   js errors:", errors[:6])
    sys.exit(0 if ok else 1)
