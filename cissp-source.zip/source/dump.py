#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""List questions whose correct choice gives itself away by length."""
import json, sys, os
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
P=json.load(open(os.path.join(HERE,"payload.json"),encoding="utf-8"))
import options_fix
done=set(r[0] for r in options_fix.OPT)
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
cnt=int(sys.argv[2]) if len(sys.argv)>2 else 60
only=sys.argv[3] if len(sys.argv)>3 else None
bad=[]
for q in P["questions"]:
    L=[len(o) for o in q["o"]]; a=q["a"]
    o=max(L[i] for i in range(len(L)) if i!=a)
    if L[a]-o>=6 and L[a]>=1.25*o:
        if only and q["d"]!=only: continue
        bad.append((o,q))
print("# 対象 %d問 (表示 %d-%d)"%(len(bad),start,min(start+cnt,len(bad))))
for o,q in bad[start:start+cnt]:
    mode="TRIM" if o>=14 else "FULL"
    print("%s [%s] %s %s"%(q["i"],mode,q["d"],q["q"]))
    for i,x in enumerate(q["o"]):
        print("   %s %s"%("*" if i==q["a"] else " ",x))
